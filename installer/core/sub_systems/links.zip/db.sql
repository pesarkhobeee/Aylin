
--
-- Table structure for table `links`
--

CREATE TABLE IF NOT EXISTS `links` (
  `l_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `l_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `l_url` varchar(200) COLLATE utf8mb4_persian_ci NOT NULL,
  `lg_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `links_group`
--

CREATE TABLE IF NOT EXISTS `links_group` (
  `lg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lg_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`lg_id`),
  UNIQUE KEY `lg_name` (`lg_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `links_logo`
--

CREATE TABLE IF NOT EXISTS `links_logo` (
  `ll_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ll_title` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `ll_url` varchar(200) COLLATE utf8mb4_persian_ci NOT NULL,
  `ll_img_url` varchar(200) COLLATE utf8mb4_persian_ci NOT NULL,
  `lg_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ll_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci AUTO_INCREMENT=1 ;

