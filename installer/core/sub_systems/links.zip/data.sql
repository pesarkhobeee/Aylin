
INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES
(0, 'links', 'root', 'acl'),
(0, 'slide_show', '0', 'config_links'),
(0, 'slide_height', '371', 'config_links'),
(0, 'slide_weight', '950', 'config_links'),
(0, 'show_just_in_homepage', '1', 'config_links');



INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES
(11, 'پیوندها', '/links', 'root', NULL),
(0, 'مدیریت', '/links', 'root', 11),
(0, 'گروه بندی', '/links/links_group', 'root', 11),
(0, 'لوگوها', 'links/links_logo', 'root', 11),
(0, 'اسلاید', 'links/slide/', 'root', 11);


