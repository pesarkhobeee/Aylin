
INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES
(0, 'links', 'root', 'acl'),
(0, 'slide_show', '0', 'config_links'),
(0, 'slide_height', '371', 'config_links'),
(0, 'slide_weight', '950', 'config_links'),
(0, 'show_just_in_homepage', '1', 'config_links');

INSERT INTO `links_group` (`lg_id`, `lg_name`) VALUES
(0, 'slide');

INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES
(11, 'پیوندها', '/links', 'root', NULL),
(0, 'مدیریت', '/links', 'root', 11),
(0, 'گروه بندی', '/links/links_group', 'root', 11),
(0, 'لوگوها', 'links/links_logo', 'root', 11),
(0, 'اسلاید', 'links/slide/', 'root', 11);


--
-- Dumping data for table `links_group`
--

INSERT INTO `links_group` (`lg_id`, `lg_name`) VALUES
(2, 'dashboard');



--
-- Dumping data for table `links_logo`
--

INSERT INTO `links_logo` (`ll_id`, `ll_title`, `ll_url`, `ll_img_url`, `lg_id`) VALUES
(1, 'مدیریت کاربران', 'users/show_users', 'dc7c3-Users.png', 2),
(2, 'مدیریت برگه ها', 'content', '86eb4-Copy.png', 2),
(3, 'مدیریت منو ها', 'menu/index', 'cb813-Database.png', 2),
(4, 'پشتیبان گیری', 'aylin_base/backup_dl', '135e6-Drive-Download.png', 2),
(5, 'مدیریت فایل ها', 'aylin_base/upload', 'af719-Media.png', 2),
(6, 'تنظیمات', 'aylin_base/config', 'eebdd-Wrench.png', 2),
(7, 'پیغام ها', 'message/management', 'bddf1-Message.png', 2),
(8, 'پیوند ها', 'links', '27a89-Link.png', 2),
(9, 'مدیریت لوگو ها', 'links/links_logo', '22c94-Postage-Stamp.png', 2),
(10, 'اسلاید ها', 'links/slide', '1571c-Desktop.png', 2),
(11, 'اخبار', 'news/management', '584fb-Megaphone.png', 2),
(12, 'خبرنامه', 'newsletter', '2221e-Quill.png', 2),
(13, 'نظرسنجی', 'polls/poll', '2b951-Format-Bullets.png', 2),
(14, 'درخواست ها', 'tickets', 'd17d4-Balloon.png', 2),
(15, 'فرم ساز', 'forms/management', '70d3f-Application.png', 2);


