<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class links extends CI_Controller {
		// extends CI_Controller for CI 2.x users

	public function __construct()
	{
	            parent::__construct();
	            // Your own constructor code
	          

	           
	            $this->aylin->login_check();
						if(!$this->aylin->acl_check($this->uri->segment(1)))
							redirect('/users/login', 'refresh');

	        /* Standard Libraries of codeigniter are required */
        $this->load->database();
        $this->load->helper('url');
        /* ------------------ */ 
 
        $this->load->library('grocery_CRUD');			
		
	}
	
	public function index()
	{
		$crud = new grocery_CRUD();
 
 
		
        $crud->set_table('links');
        $crud->order_by('l_id','desc');
        $crud->set_relation('lg_id','links_group','lg_name');
        $crud->display_as('lg_id','گروه');
        $crud->display_as('l_name','عنوان');
        $crud->display_as('l_url','آدرس');
         $crud->set_theme('datatables');
        $output = $crud->render();
 
        $this->_example_output($output);	
		
	}	
	
	public function links_group()
	{
		$crud = new grocery_CRUD();
 
        $crud->set_table('links_group');
        $crud->display_as('lg_name','گروه');
        $crud->set_relation('lg_id','links_group','lg_name');
        $crud->set_theme('datatables');
        $output = $crud->render();
 
        $this->_example_output($output);                
    }
    
    public function links_logo()
	{
		$crud = new grocery_CRUD();
 
		$crud->callback_before_insert(array($this,'_image_thumb'));
		$crud->callback_after_update(array($this,'_image_thumb'));
		$crud->callback_column('ll_img_url',array($this,'_callback_img_url'));
		
		$crud->where("lg_name !=","slide");
		 $crud->required_fields('lg_id','ll_img_url','ll_url','ll_title');
        $crud->set_table('links_logo');
        $crud->set_relation('lg_id','links_group','lg_name');
        $crud->set_field_upload('ll_img_url','assets/uploads/files');
        $crud->display_as('ll_title','عنوان');
        $crud->display_as('ll_url','آدرس');
        $crud->display_as('ll_img_url','تصویر');
        $crud->display_as('lg_id','گروه');
        $crud->set_theme('datatables');
        $crud->set_language('persian');
        $crud->order_by('ll_id','desc');
        $output = $crud->render();
        $this->_example_output($output);                
    }
    
    public function _callback_img_url($value, $row)
	{
		$img = substr($value,0,-4)."_thumb".substr($value,-4);
		  return "<a href='".site_url($row->ll_url)."'><img  alt='".$row->ll_title."' src='".base_url("assets/uploads/files/") ."/$img' /></a>";
	}
	
	function _image_thumb($post_array,$primary_key)
	{
		$config['image_library'] = 'gd2';
		$config['source_image'] = 'assets/uploads/files/'.$post_array["ll_img_url"];
		$config['create_thumb'] = TRUE;
		$config['maintain_ratio'] = TRUE;
		$config['width'] = 200;
		$config['height'] = 150;
		
		$this->load->library('image_lib', $config);
		if ( !$this->image_lib->resize())
		{
			echo $this->image_lib->display_errors();
		}
		
		return true;
	
	}
	
	
	
	public function slide()
	{
		$crud = new grocery_CRUD();
 
		//$crud->callback_after_upload(array($this,'_slide_resize'));
		$crud->callback_column('ll_img_url',array($this,'_slide_img_url'));
		$crud->callback_before_insert(array($this,'_slide_callback_before_insert'));
		
		 $crud->required_fields('ll_img_url','ll_url','ll_title');
		$crud->change_field_type('lg_id','invisible');
		$crud->where('lg_name','slide');
        $crud->set_table('links_logo');
        $crud->set_relation('lg_id','links_group','lg_name');
        $crud->set_field_upload('ll_img_url','assets/uploads/files');
        $crud->display_as('ll_title','عنوان');
        $crud->display_as('ll_url','آدرس');
        $crud->display_as('ll_img_url','تصویر');
        $crud->display_as('lg_id','گروه');
        $crud->set_theme('datatables');
        $crud->set_language('persian');
        $crud->order_by('ll_id','desc');
        $output = $crud->render();
        $this->_example_output($output);                
    }
	
	function _slide_resize($uploader_response,$field_info, $files_to_upload)
	{

		$this->load->library('image_moo');
	 
		//Is only one file uploaded so it ok to use it with $uploader_response[0].
		$file_uploaded = $field_info->upload_path.'/'.$uploader_response[0]->name; 
		
		$slide_weight=$this->aylin->config("slide_weight","config_links");
		$slide_height=$this->aylin->config("slide_height","config_links");
		
		$this->image_moo->load($file_uploaded)->resize($slide_weight,$slide_height)->save($file_uploaded,true);
	 
		return true;
	}
	
	function _slide_img_url($value, $row)
	{
		  return "<a href='".site_url($row->ll_url)."'><img height='200px'  alt='".$row->ll_title."' src='".base_url("assets/uploads/files/") ."/$value' /></a>";
	}
	
	function _slide_callback_before_insert($post_array)
	{
		$this->db->where('lg_name', 'slide'); 
		$query = $this->db->get("links_group");
		$post_array['lg_id'] =$query->row("lg_id");
		return $post_array;
	}
 
    function _example_output($output = null)
    {
		$this->load->view('admin_them/header');
		$this->load->view('our_template.php',$output);
		$this->load->view('admin_them/footer');
            
    }	
		
		
}



?>
