
--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `n_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `n_title` varchar(200) COLLATE utf8mb4_persian_ci NOT NULL,
  `n_writer_id` int(10) unsigned NOT NULL,
  `ng_id` int(10) unsigned NOT NULL,
  `n_tags` text COLLATE utf8mb4_persian_ci NOT NULL,
  `n_create_date` date NOT NULL,
  `n_content` longtext COLLATE utf8mb4_persian_ci NOT NULL,
  `n_identity_img` varchar(250) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `news_group`
--

CREATE TABLE IF NOT EXISTS `news_group` (
  `ng_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ng_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`ng_id`),
  UNIQUE KEY `ng_name` (`ng_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `news_tags`
--

CREATE TABLE IF NOT EXISTS `news_tags` (
  `nt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nt_name_fa` varchar(200) COLLATE utf8mb4_persian_ci NOT NULL,
  `nt_name_en` varchar(200) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`nt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci AUTO_INCREMENT=1 ;

