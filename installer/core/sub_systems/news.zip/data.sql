
INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES
(0, 'show_identity_img', '1', 'config_news'),
(0, 'show_writer', '1', 'config_news'),
(0, 'show_news_group', '1', 'config_news'),
(0, 'show_news_date', '1', 'config_news'),
(0, 'news_per_page', '5', 'config_news'),
(0, 'show_news_line', '25', 'config_news'),
(0, 'show_detail_link', '1', 'config_news'),
(0, 'news', 'root', 'acl');



INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES
(10, 'اخبار', '/news', 'root', NULL),
(0, 'گروه بندی', '/news/news_group', 'root', 10),
(0, 'مدیریت', 'news/management', 'root', 10);



INSERT INTO `news_group` (`ng_id`, `ng_name`) VALUES
(1, 'عمومی');

