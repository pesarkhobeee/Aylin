<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class news extends CI_Controller {
		// extends CI_Controller for CI 2.x users

	public function __construct()
	{
	            parent::__construct();
	            // Your own constructor code
	         
	          /*
	            
	            $this->aylin->login_check();
						if(!$this->aylin->acl_check($this->uri->segment(1)))
							redirect('/users/login', 'refresh');
				*/
	        /* Standard Libraries of codeigniter are required */
        $this->load->database();
        $this->load->helper('url');
        /* ------------------ */ 
 
        $this->load->library('grocery_CRUD');			
		//$this->output->enable_profiler(TRUE);
	}
	
	
	public function news_group()
	{
	$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
		
	 $crud = new grocery_CRUD();
 
        $crud->set_table('news_group');
        $crud->display_as('ng_name','گروه خبری');
         $crud->set_theme('datatables');
        $output = $crud->render();
 
		$this->load->view('admin_them/header');
        $this->_example_output($output);       
        $this->load->view('admin_them/footer');         
    }
    
    function management()
    {
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
			
		$crud = new grocery_CRUD();
		$crud->set_table('news');
		
		$crud->display_as('n_title','عنوان');
		$crud->display_as('n_tags','تگ ها');
		$crud->display_as('n_create_date','تاریخ ایجاد');
		$crud->display_as('n_content','محتوا');
		$crud->display_as('n_identity_img','تصویر شاخص');
		$crud->display_as('n_writer_id','نویسنده');
		$crud->display_as('ng_id','گروه');
		
		$crud->set_relation('ng_id','news_group','ng_name');
		$crud->set_relation('n_writer_id','users','username');
		
		$crud->set_theme('datatables');
		
		$crud->order_by('n_create_date','desc');
		$crud->order_by('n_id','desc');
		
		$crud->unset_columns('n_content','n_identity_img');
		$crud->unset_edit_fields('n_create_date');	 
		//$crud->unset_add_fields('n_writer_id','n_create_date');
		$crud->change_field_type('n_create_date','invisible');
		$crud->change_field_type('n_writer_id','invisible');
		
		$crud->callback_before_insert(array($this,'_news_callback_before_insert'));
		$crud->callback_column('n_create_date',array($this,'_callback_n_create_date'));
		//$crud->callback_column('n_identity_img',array($this,'_callback_n_identity_img'));
		$crud->callback_after_upload(array($this,'_callback_n_identity_img'));
		
		$crud->change_field_type('n_content','text');
		
		$crud->unset_texteditor('n_tags');
		
		$crud->set_field_upload('n_identity_img','assets/uploads/files');
		
		if($this->aylin->config("enable_newslater_in_news","config_site")==1)
			$crud->add_action('خبرنامه', '', 'newsletter/index','ui-icon-plus');
		
	    $output = $crud->render();
		$this->load->view('admin_them/header');
        $this->_example_output($output);       
        $this->load->view('admin_them/footer'); 		
	}
	 
	function _callback_n_create_date($value, $row)
	{	 
		$this->load->library('JalaliCalendar');   
		$gdate=$value;
		list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
		list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
		$jdate=$jyear."-".$jmonth."-".$jday;  
		return $jdate;
	}
 
 
	function _callback_n_identity_img($uploader_response,$field_info, $files_to_upload)
	{

		$this->load->library('image_moo');
	 
		//Is only one file uploaded so it ok to use it with $uploader_response[0].
		$file_uploaded = $field_info->upload_path.'/'.$uploader_response[0]->name; 
	 
		$this->image_moo->load($file_uploaded)->resize(300,240)->save($file_uploaded,true);
	 
		return true;
	}
 

	
	function _news_callback_before_insert($post_array)
	{
		$post_array['n_writer_id'] = $this->session->userdata('id');
		$post_array['n_create_date'] = date("Y-m-d");
		return $post_array;
	}
 
    function _example_output($output = null)
    {
        $this->load->view('our_template.php',$output);    
    }
    
    function index($offset=0)
    {	
		$per_page=$this->aylin->config("news_per_page","config_news");		
		
		$this->load->library('pagination');
		$config['base_url'] = base_url('index.php/news/index');
		$config['total_rows'] = $this->db->count_all('news');
		$config['per_page'] = $per_page;
		$this->pagination->initialize($config);
		
		$this->load->library('JalaliCalendar');    
		
		$this->db->order_by("n_create_date", "desc"); 
		$this->db->order_by("n_id", "desc"); 
		$this->db->join('news_group', 'news.ng_id = news_group.ng_id', 'left');
		$this->db->join('users', 'news.n_writer_id = users.id', 'left');
		$this->data['query']  = $this->db->get("news",$per_page,$offset);
		$this->load->view('header');
		$this->load->view('news/show_news', $this->data);
		$this->load->view('footer');
		

		
	}
	
	function search()
	{
		$keyword=$_POST["keyword"];
		$this->load->library('JalaliCalendar');    
		
		$this->db->order_by("n_create_date", "desc"); 
		$this->db->order_by("n_id", "desc"); 
		$this->db->join('news_group', 'news.ng_id = news_group.ng_id', 'left');
		$this->db->join('users', 'news.n_writer_id = users.id', 'left');
		$this->db->like('n_title', $keyword);
		$this->db->or_like('n_content', $keyword); 
		$this->db->or_like('n_tags', $keyword);
		$this->data['query']  = $this->db->get("news");
		$this->load->view('header');
		$this->load->view('news/show_search', $this->data);
		$this->load->view('footer');
	}	
	
	function news_detail($n_id)
	{	
		$this->load->library('JalaliCalendar');    
		
		$this->db->order_by("n_create_date", "desc"); 
		$this->db->order_by("n_id", "desc"); 
		$this->db->join('news_group', 'news.ng_id = news_group.ng_id', 'left');
		$this->db->join('users', 'news.n_writer_id = users.id', 'left');
		$this->db->where("n_id",$n_id);
		$this->data['query']  = $this->db->get("news");
		$this->load->view('header');
		$this->load->view('news/news_detail', $this->data);
		$this->load->view('footer');
	}
	
	
	function subject_archive($ng_id)
	{	
		$this->load->library('JalaliCalendar');    
		
		$this->db->order_by("n_create_date", "desc"); 
		$this->db->order_by("n_id", "desc"); 
		$this->db->join('news_group', 'news.ng_id = news_group.ng_id', 'left');
		$this->db->join('users', 'news.n_writer_id = users.id', 'left');
		$this->db->where("news.ng_id",$ng_id);
		$this->data['query']  = $this->db->get("news");
		$this->load->view('header');
		$this->load->view('news/subject_archive', $this->data);
		$this->load->view('footer');
	}
	
	
	
	public function rss(){
		
		$this->load->helper('xml');  
        $this->load->helper('text'); 
        $data['encoding'] = 'utf-8';  
        $this->db->order_by("n_id", "desc"); 
        $data['posts'] = $this->db->get('news',10);  
        header("Content-Type: application/rss+xml");  
        $this->load->view('news/rss', $data);  
		
		
	}		
}



?>
