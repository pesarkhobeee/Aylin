<?php  echo '<?xml version="1.0" encoding="' . $encoding . '"?>' . "\n"; ?>  
   <rss version="2.0">  
	   <channel> 
	   <title><?php echo htmlspecialchars($this->aylin->config("title","config_site"));  ?></title>
	   <link><?php echo site_url(); ?>  </link> 
	   <?php foreach($posts->result() as $post): ?>  
		   <item>  
		   <title><?php echo $post->n_title; ?></title>
			 <link><?php echo site_url('news/news_detail/' . $post->n_id) ?>  </link>  
			   <description> <?php echo htmlspecialchars(character_limiter($post->n_content, 200)); ?> </description>  
			   <pubdate><?php echo $post->n_create_date; ?></pubdate>  
		   </item>  
	   <?php endforeach; ?>  
	   
	   </channel>  
   </rss>  
