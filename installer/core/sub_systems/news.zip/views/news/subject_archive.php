<?php
$show_news_line = $this->aylin->config("show_news_line","config_news");
$show_identity_img = $this->aylin->config("show_identity_img","config_news");
$show_writer = 	$this->aylin->config("show_writer","config_news");
$show_news_group = $this->aylin->config("show_news_group","config_news");
$show_news_date =	$this->aylin->config("show_news_date","config_news");		
$show_detail_link = $this->aylin->config("show_detail_link","config_news");


	foreach ($query->result() as $row)
	{
		
		$text="";
		$counter=0;
		$array = explode("\n", $row->n_content);
		foreach($array as $line)
		{
			$counter++;
			$text.=$line."\n";
			if($counter==$show_news_line)
				break;
		}
		
		if($show_identity_img ==1)
		{
			if($row->n_identity_img=="")
			{
				$img="<img class='news_img' src='".base_url("/assets/img")."/news.png' />";
			}
			else
			{
				$img= "<img class='news_img' src='".base_url("/assets/uploads/files")."/".$row->n_identity_img."' />";
			}
		}
		else
		{
			$img="";
		}
		
		if($show_writer == 1)
		{
			$writer="<div class='news_meta_data' style='text-align:left;'>نویسنده: ".$row->username."</div>";
		}
		else
		{
			$writer="";
		}
		
		
		if($show_news_group ==1)
		{
			$news_group="<div class='news_meta_data'>گروهبندی: ".anchor('news/subject_archive/'.$row->ng_id, $row->ng_name)."</div>";
		}
		else
		{
			$news_group="";
		}
		
		if( $show_news_date ==1)
		{	
			$gdate=$row->n_create_date;
			list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
			list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
			$jdate=$jyear."-".$jmonth."-".$jday; 
		}
		else
		{
			$jdate="";
		}
		
		if($show_detail_link == 1)
		{
			$detail_link=anchor('news/news_detail/'.$row->n_id, "مشاهده کامل خبر");
		}
		else
		{
			$detail_link="";
		}		
		
		
		
	echo  "<table class='news'>
			<tr>
				<td colspan='2' ><div class='news_meta_data' style='font-weight:bold;'>".$row->n_title."</div></td>
				<td><div class='news_meta_data' style='text-align:left;'>".$jdate."</div></td>
			</tr>
			<tr>
				<td colspan='3'><div class='news_content'>".$img.$text."</div></td>
			</tr>
			<tr>
				<td>$news_group</td>
				<td>$writer</td>
				<td style='text-align:left;'>$detail_link</td>
			</tr>
			</table>
			";
	}
	

	
	?>
