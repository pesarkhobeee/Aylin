<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class tickets extends CI_Controller {
	
public function __construct()
{
	parent::__construct();
	
	$this->load->helper('url'); //You should autoload this one ;)		
	//$this->output->enable_profiler(TRUE);
	$this->load->helper('form');
}

public function ticket($ticket_id)
{
	//show all response for one ticket
	
	$this->aylin->login_check();
	if(!$this->aylin->acl_check($this->uri->segment(1)))
		redirect('/users/login', 'refresh');
		
	$this->load->helper('ckeditor');
		//Ckeditor's configuration
		$data['ckeditor'] = array(
 
			//ID of the textarea that will be replaced
			'id' 	=> 	'content',
			'path'	=>	'assets/ckeditor',

 
			//Replacing styles from the "Styles tool"
			'styles' => array(
 
				//Creating a new style named "style 1"
				'style 1' => array (
					'name' 		=> 	'Blue Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 	=> 	'Blue',
						'font-weight' 	=> 	'bold'
					)
				),
 
				//Creating a new style named "style 2"
				'style 2' => array (
					'name' 	=> 	'Red Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 		=> 	'Red',
						'font-weight' 		=> 	'bold',
						'text-decoration'	=> 	'underline'
					)
				)				
			)
		);
		
		
		if(isset($_POST["response_description"]))
		{
			$_POST["response_description"]=htmlspecialchars($_POST["response_description"]);
			$_POST["response_user"]=$this->session->userdata("id");
			if($this->db->insert('hm_ticket_responses', $_POST))
			{
					$this->db->where('ticket_id', $_POST["hm_ticket_id"]);
					if($this->session->userdata("user_group")=="users")
					{
						$this->db->update('hm_tickets', array("ticket_status"=>"در انتظار پاسخ"));


                        	//If sms subsystem install and it's enable for ticket it is send sms 
					        if($this->aylin->config("enable_sms_in_tickets","config_site") == 1)
					        {
                                $numbers = array();
                                //get manager mobile number
						        $query = $this->db->get_where("hm_tickets",array("ticket_id"=>$_POST['hm_ticket_id']));
						        $row = $query->row();
						        $hm_ticket_segment = $row->hm_ticket_segment;
                                $ticket_uniq_ir_code = $row->ticket_uniq_ir_code;
						        $query = $this->db->get_where("hm_ticket_segments",array("segment_id"=>$hm_ticket_segment));
						        $row = $query->row();
						        $manager_id = $row->segment_manager;
						        $query = $this->db->get_where("customer_detail",array("cd_users_id"=>$manager_id));
						        $row = $query->row();
						        if($query->num_rows()==1)
						        {
							        $number = $row->cd_mobile;
							        if($number!="")
								        array_push($numbers,$this->convert($number));
						        }	

						        if(!empty($numbers))
						        {
							        $msg="پاسخی از طرف کاربر به درخواست ای به شماره روبرو داده شد: ".$ticket_uniq_ir_code;
							        $this->aylin->sms($msg,$numbers);
						        }

                            }


					}
					else
					{
						$this->db->update('hm_tickets', array("ticket_status"=>"پاسخ داده شده")); 


                        	//If sms subsystem install and it's enable for ticket it is send sms 
					        if($this->aylin->config("enable_sms_in_tickets","config_site") == 1)
					        {
                                $numbers = array();
                                //get user mobile number
						        $query = $this->db->get_where("hm_tickets",array("ticket_id"=>$_POST['hm_ticket_id']));
						        $row = $query->row();
						        $ticket_user = $row->ticket_user;
                                $ticket_uniq_ir_code = $row->ticket_uniq_ir_code;
						        $query = $this->db->get_where("customer_detail",array("cd_users_id"=>$ticket_user));
						        $row = $query->row();
						        if($query->num_rows()==1)
						        {
							        $number = $row->cd_mobile;
							        if($number!="")
								        array_push($numbers,$this->convert($number));
						        }	

						        if(!empty($numbers))
						        {
							        $msg="پاسخی از طرف مدیر به درخواست ای به شماره روبرو داده شد: ".$ticket_uniq_ir_code;
							        $this->aylin->sms($msg,$numbers);
						        }

                            }

					}
					
					$data['massege'] = 'پاسخ شما با موفقیت ارسال شد';
			}
		}
		
		
		$this->load->helper('form');
		$this->load->library('JalaliCalendar'); 
		
		$data['ticket_id'] = $ticket_id;
		$data['userid']=$this->session->userdata("id");
		
		$this->db->where('ticket_id', $ticket_id);
		$data['hm_tickets'] = $this->db->get('hm_tickets');
		
		$this->db->where('hm_ticket_id', $ticket_id);
		$this->db->join('users', 'users.id = hm_ticket_responses.response_user');
		$data['hm_ticket_responses'] = $this->db->get('hm_ticket_responses');
		
		$this->load->view('admin_them/header');
		$this->load->view('ticket/ticket',$data);
		$this->load->view('admin_them/footer');

}



	
public function index(){
	//manage all tickets

	$this->aylin->login_check();
	if(!$this->aylin->acl_check($this->uri->segment(1)))
		redirect('/users/login', 'refresh');
		
    $this->load->library('grocery_CRUD');	
    $crud = new grocery_CRUD();
    
   $crud->set_theme('datatables');
   $crud->unset_add();
   $crud->unset_edit();
   //$crud->unset_delete();
   
    $crud->set_table('hm_tickets')
    ->set_subject('Tickets')
      ->columns('ticket_title','hm_ticket_segment','ticket_status','ticket_register_date','ticket_user','ticket_uniq_ir_code')
    ->display_as('ticket_title','عنوان')
    ->display_as('hm_ticket_segment','بخش')
    ->display_as('ticket_description','توضیح')
    ->display_as('ticket_status','وضعیت')
    ->display_as('ticket_user','کاربر')
    ->display_as('ticket_register_date','زمان ارسال')
    ->display_as('ticket_uniq_ir_code','کد رهگیری');
    
	if($this->session->userdata('user_group')!="root")
	{
		if($this->session->userdata('user_group')=="users")
		{
			$crud->where('ticket_user',$this->session->userdata('id'));
		}else{
			$this->db->where('segment_manager', $this->session->userdata('id'));
			$query= $this->db->get("hm_ticket_segments");
            foreach ($query->result() as $row)
			{
				$crud->where('hm_ticket_segment',$row->segment_id);
			}		
		}
			
	}
    
    $crud->set_relation('hm_ticket_segment','hm_ticket_segments','segment_title');
    $crud->set_relation('ticket_user','users','username');
    
	$crud->callback_column('ticket_register_date',array($this,'_callback_n_create_date'));
    $crud->add_action('بستن', '', 'tickets/finish','ui-icon-plus');
    $crud->add_action('مشاهده و پاسخ', '','tickets/ticket','ui-icon-plus');

    $crud->unset_texteditor('ticket_description','full_text');
    $output = $crud->render();
   
	$this->_example_output($output);

}

function ticket_segments()
{
	//manage tickets segments
	$this->aylin->login_check();
	if(!$this->aylin->acl_check("tickets_root"))
		redirect('/users/login', 'refresh');
		
	$this->load->library('grocery_CRUD');
	$crud = new grocery_CRUD();
	$crud->set_table('hm_ticket_segments');
	$crud->display_as('segment_title','عنوان');
	$crud->display_as('segment_manager','مسئول بخش');
	$crud->display_as('segment_id','کد یکتا');
	
	$crud->set_relation('segment_manager','users','username ');
	$crud->set_theme('datatables');
	$output = $crud->render();

	$this->_example_output($output);		
	
}
  
function detect_zoj_or_fard($str)
{
	if($str!="")
	{
		$tmp=0;
		for($i=0;$i<strlen($str);$i++)
		{
			$tmp+= substr($str,-1+$i,1);	
		}
		return $tmp%2;
	}
}
  
public function show_ticket(){
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
			
		$this->load->helper('form');
		
		$data['userid']=$this->session->userdata("id");
		
		$this->db->where('ticket_uniq_ir_code', $_POST['ticket_uniq_ir_code']);
		$this->db->where('ticket_user', $this->session->userdata("id"));
		$data['hm_tickets'] = $this->db->get('hm_tickets');
		if($data['hm_tickets']->num_rows()!=0)
		{
			foreach($data['hm_tickets']->result() as $row)
				$ticket_id=$row->ticket_id;
			
			
			redirect('/tickets/ticket/'.$ticket_id, 'refresh');
		}else{
			$data['error'] = 'درخواستی با مشخصات داده شده یافت نشد!';
			$this->load->view('admin_them/header');
			$this->load->view('ticket/message', $data);
			$this->load->view('admin_them/footer');
		}

}
  
    
function send_ticket()
{
	$this->aylin->login_check();
	if(!$this->aylin->acl_check($this->uri->segment(1)))
		redirect('/users/login', 'refresh');
		
	$this->load->helper('form');
	$this->load->helper('ckeditor');
			//Ckeditor's configuration
	$data['ckeditor'] = array(
 
			//ID of the textarea that will be replaced
			'id' 	=> 	'ticket_description',
			'path'	=>	'assets/ckeditor',

 
			//Replacing styles from the "Styles tool"
			'styles' => array(
 
				//Creating a new style named "style 1"
				'style 1' => array (
					'name' 		=> 	'Blue Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 	=> 	'Blue',
						'font-weight' 	=> 	'bold'
					)
				),
 
				//Creating a new style named "style 2"
				'style 2' => array (
					'name' 	=> 	'Red Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 		=> 	'Red',
						'font-weight' 		=> 	'bold',
						'text-decoration'	=> 	'underline'
					)
				)				
			)
		);
		
	
	
		
		
		
		if(isset($_POST["ticket_description"]))
		{
			$_POST["ticket_description"]=htmlspecialchars($_POST["ticket_description"]);
			$_POST["ticket_user"] = $this->session->userdata("id");
				
				$this->db->where('ticket_register_date', date("Y-m-d"));
				$this->db->from('hm_tickets');
				$daily_ticket_number = $this->db->count_all_results() +1;
				$this->load->library('JalaliCalendar');
				$gdate=$_POST['ticket_register_date'];
				list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
				list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
				$jyear = substr($jyear, -2);
				if(strlen($jmonth)==1)$jmonth="0".$jmonth;
				if(strlen($jday)==1)$jday="0".$jday;
				$jdate=$jyear.$jmonth.$jday;
				if(strlen($daily_ticket_number)==1)$daily_ticket_number="00".$daily_ticket_number;
				if(strlen($daily_ticket_number)==2)$daily_ticket_number="0".$daily_ticket_number;
				$zojo_fard = $this->detect_zoj_or_fard("0912".$_POST['hm_ticket_segment'].$daily_ticket_number.$jdate);
				$_POST['ticket_uniq_ir_code']= "0912-".$_POST['hm_ticket_segment']."-".$daily_ticket_number."-".$jdate."-".$zojo_fard;
				if($this->db->insert('hm_tickets', $_POST))
				{
					$data['massege'] = 'درخواست پشتیبانی شما با موفقیت فرستاده شد'.'<br>کد رهگیری شما:<br>'.$_POST['ticket_uniq_ir_code'];
				

					//If sms subsystem install and it's enable for ticket it is send sms 
					if($this->aylin->config("enable_sms_in_tickets","config_site") == 1)
					{
						$numbers = array();
						
						//get user mobile number
						$query = $this->db->get_where("customer_detail",array("cd_users_id"=>$this->session->userdata('id')));
						$row = $query->row();
						if($query->num_rows()==1)
						{
							$number = $row->cd_mobile;
							if($number!="")
								array_push($numbers,$this->convert($number));
						}
						
						//get manager mobile number
						$query = $this->db->get_where("hm_ticket_segments",array("segment_id"=>$_POST['hm_ticket_segment']));
						$row = $query->row();
						$manager_id = $row->segment_manager;
						$query = $this->db->get_where("customer_detail",array("cd_users_id"=>$manager_id));
						$row = $query->row();
						if($query->num_rows()==1)
						{
							$number = $row->cd_mobile;
							if($number!="")
								array_push($numbers,$this->convert($number));
						}	

						if(!empty($numbers))
						{
							$msg="درخواست جدید فرستاده شد و کد رهگیری آن: ".$_POST['ticket_uniq_ir_code'];
							$this->aylin->sms($msg,$numbers);
						}
					}
	
				}
					
		}else{
				$data['hm_ticket_segments']  = $this->db->get("hm_ticket_segments");
		}


		$this->load->view('admin_them/header');
		$this->load->view('ticket/send', $data);
		$this->load->view('admin_them/footer');

}

	function _callback_n_create_date($value, $row)
	{	 
		$this->load->library('JalaliCalendar');   
		$gdate=$value;
		list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
		list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
		$jdate=$jyear."-".$jmonth."-".$jday;  
		return $jdate;
	}

    function _example_output($output = null)
    {
		$this->load->view('admin_them/header');
		$this->load->view('our_template.php',$output);
		$this->load->view('admin_them/footer');
            
    }	
    
    
    function finish($id=NULL)
    {
	// change a ticket status to finish
	$this->aylin->login_check();
	if(!$this->aylin->acl_check($this->uri->segment(1)))
		redirect('/users/login', 'refresh');
		
		if($id!==NULL)
		{
					
					if($this->session->userdata("user_group")=="users")
					{
						
						$this->db->from('hm_tickets');
						$this->db->where('ticket_id', $id);
						$this->db->where('ticket_user', $this->session->userdata("id"));
						$query= $this->db->get();
						$row = $query->row();
						if($query->num_rows()==1){				
							$this->db->where('ticket_id', $id);	
							$this->db->update('hm_tickets', array("ticket_status"=>"بسته شده"));
							$data['massege'] = 'درخواست مورد نظر با موفقیت بسته شد';
						}else{
							$data['massege'] = 'شما اجازه این کار را ندارید';
						}
					}
					else
					{
						$this->db->where('ticket_id', $id);
						$this->db->update('hm_tickets', array("ticket_status"=>"بسته شده")); 
						$data['massege'] = 'درخواست مورد نظر با موفقیت بسته شد';
					}
					$this->load->view('admin_them/header');
					$this->load->view('ticket/message.php',$data);
					$this->load->view('admin_them/footer');	
								
		}
		
	}
	
    function track()
    {

	        $this->aylin->login_check();
	        if(!$this->aylin->acl_check($this->uri->segment(1)))
		        redirect('/users/login', 'refresh');
		
	        $this->load->view('admin_them/header');
	        $this->load->view('ticket/track');
	        $this->load->view('admin_them/footer');
    }

	function convert($string) {
		$persian = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');
		$num = range(0, 9);
		return str_replace($persian, $num, $string);
	}


}
