<script type="text/javascript">
            /* <![CDATA[ */
            jQuery(function(){
                jQuery("#ticket_uniq_ir_code").validate({
                    expression: "if (VAL!='') return true; else return false;",
                    message: "&nbsp;لطفا این فیلد را پر کنید&nbsp;"
                });
                 jQuery("#ticket_title").validate({
                    expression: "if (VAL!='') return true; else return false;",
                    message: "&nbsp;لطفا این فیلد را پر کنید&nbsp;"
                });                             
                jQuery(" #ticket_description").validate({
                    expression: "if (VAL!='') return true; else return false;",
                    message: "&nbsp;لطفا این فیلد را پر کنید&nbsp;"
                });              
                             
                 
                 
                       
                
            });
            /* ]]> */
        </script>

<?php
	if(isset($massege))
	{
		echo "<div class='fade in alert alert-success'><a data-dismiss='alert' class='close'>×</a>$massege</div>";
	}else{
?>
<div style="direction:rtl;padding:5px;margin:5px;">
<h3>ایجاد درخواست جدید</h3>
<?php echo form_open('tickets/send_ticket'); ?>
	<div class="control-group">
		<label for="ticket_title">عنوان شکایت *</label>
		<div class="controls">
			<input style="width:300px" type="text" name="ticket_title" id="ticket_title" />
		</div>
	</div>
	<div class="control-group">
		<label for="ticket_user">بخش *</label>
		<div class="controls">
			<select style="width:300px" name="hm_ticket_segment">
				<?php
						foreach ($hm_ticket_segments->result() as $row)
						{
							echo "<option value='".$row->segment_id."'> ".$row->segment_title."</option>";
						}
				?>
			</select>
		</div>
	</div>
	<div class="control-group">
		<label for="ticket_description">متن شکایت *</label>
		<div class="controls">
			<textarea style="width:300px;height:150px;" name="ticket_description" id="ticket_description" ></textarea>
		</div>
		<?php echo display_ckeditor($ckeditor); ?>
	</div>
	<br>
	<input type="submit" value="ارسال درخواست" class="btn" />
	<input type="hidden" name="ticket_register_date" value="<?php echo date("Y-m-d"); ?>" />
	<input type="hidden" name="ticket_status" value="در انتظار پاسخ"  />
<?php echo form_close(); ?>
</div>
<?php
}
?>
<hr>
<div style="direction:rtl;padding:5px;margin:5px;">
<?php
	if(isset($error))
	{
		echo "<div class='fade in alert alert-error'><a data-dismiss='alert' class='close'>×</a>$error</div>";
	}else{
?>
	<h3>مشاهده درخواست ها</h3>
	<?php echo form_open('tickets/show_ticket'); ?>
	<div class="control-group">
	<label for="ticket_uniq_ir_code">شماره پیگیری</label>
	<div class="controls">
	<input style="width:300px" type="text" name="ticket_uniq_ir_code" id="ticket_uniq_ir_code"/>
	</div></div>
	<br>
	<input type="submit" value="مشاهده درخواست" class="btn" />
	<?php echo form_close(); ?>
<?php
}
?>
</div>

