<?php
	if(isset($massege))
	{
		echo "<div class='fade in alert alert-success'><a data-dismiss='alert' class='close'>×</a>$massege</div>";
	}
	
	
	if(isset($error))
	{
		echo "<div class='fade in alert alert-error'><a data-dismiss='alert' class='close'>×</a>$error</div>";
	}
?>
