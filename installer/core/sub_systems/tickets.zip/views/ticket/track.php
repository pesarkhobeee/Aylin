<div style="direction:rtl;padding:5px;margin:5px;">
<?php
	if(isset($error))
	{
		echo "<div class='fade in alert alert-error'><a data-dismiss='alert' class='close'>×</a>$error</div>";
	}else{
?>
	<h3>مشاهده درخواست ها</h3>
	<?php echo form_open('tickets/show_ticket'); ?>
	<div class="control-group">
	<label for="ticket_uniq_ir_code">شماره پیگیری</label>
	<div class="controls">
	<input style="width:300px" type="text" name="ticket_uniq_ir_code" id="ticket_uniq_ir_code"/>
	</div></div>
	<br>
	<input type="submit" value="مشاهده درخواست" class="btn" />
	<?php echo form_close(); ?>
<?php
}
?>
</div>
