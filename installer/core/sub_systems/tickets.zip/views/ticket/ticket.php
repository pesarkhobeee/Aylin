<?php
	if(isset($massege))
	{
		echo "<div class='fade in alert alert-success'><a data-dismiss='alert' class='close'>×</a>$massege</div>";
	}
?>


<?php
	$status ="";
	echo  "<table width='100%' id='ticket_main'>";
	foreach($hm_tickets->result() as $row){  
		$gdate=$row->ticket_register_date;
		list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
		list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
		$jdate=$jyear."-".$jmonth."-".$jday;
	echo "
	<tr><td>عنوان</td><td>".$row->ticket_title."</td></tr>
	<tr><td>تاریخ</td><td>".$jdate."</td></tr>
	<tr><td>سوال</td><td><div style='background-color:#FFF;color:#000;padding:15px;'>".html_entity_decode($row->ticket_description)."</div></td></tr>
	";
	$status=$row->ticket_status;
	}
	echo "</table><br>";
?>



<?php
	echo  "<table style='direction:rtl;text-align:right;' class='table table-striped' width='100%'>";
	foreach($hm_ticket_responses->result() as $row){
		$gdate=$row->register_date;
		list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
		list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
		$jdate=$jyear."-".$jmonth."-".$jday;
		echo "<tr><td>".$jdate."</td>";
		echo "<td>".$row->username."</td></tr>";
		echo "<tr><td colspan='2' style='direction:rtl;text-align:right;'>".html_entity_decode($row->response_description)."</td></tr>";
		
	}
	echo "</table>";

?>	

<?php
if($status!="بسته شده")
{
 echo form_open('',array('id'=>'user_form')); 
 ?>

<textarea style="width:100%;direction:rtl;text-align:right;" cols="60" rows="12"  name="response_description" id="content">

</textarea>
<?php echo display_ckeditor($ckeditor); ?>
<br>
<input type="submit" class="btn btn-success" value="ارسال پاسخ" />
<input type="hidden" name="register_date" value="<?php echo(date('Y-m-d'));  ?>" />
<input type="hidden" name="hm_ticket_id" value="<?php echo $ticket_id; ?>" />
<?php
echo form_close();
}else{
		echo "<div class='fade in alert alert-warning'><a data-dismiss='alert' class='close'>×</a>این درخواست بسته شده است</div>";
}
 ?>
