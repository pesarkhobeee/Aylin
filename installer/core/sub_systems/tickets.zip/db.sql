
--
-- Table structure for table `hm_tickets`
--

CREATE TABLE IF NOT EXISTS `hm_tickets` (
  `ticket_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `ticket_description` text COLLATE utf8_persian_ci NOT NULL,
  `hm_ticket_segment` int(10) unsigned NOT NULL,
  `ticket_status` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `ticket_register_date` date NOT NULL,
  `ticket_user` int(10) unsigned NOT NULL,
  `ticket_uniq_ir_code` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `ticket_uniq_ir_code` (`ticket_uniq_ir_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `hm_ticket_responses`
--

CREATE TABLE IF NOT EXISTS `hm_ticket_responses` (
  `response_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `response_user` int(10) unsigned NOT NULL,
  `hm_ticket_id` int(10) unsigned NOT NULL,
  `response_description` text COLLATE utf8_persian_ci NOT NULL,
  `register_date` date NOT NULL,
  PRIMARY KEY (`response_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `hm_ticket_segments`
--

CREATE TABLE IF NOT EXISTS `hm_ticket_segments` (
  `segment_id` int(10) unsigned NOT NULL,
  `segment_title` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `segment_manager` int(10) unsigned NOT NULL,
  PRIMARY KEY (`segment_id`),
  UNIQUE KEY `segment_title` (`segment_title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;
