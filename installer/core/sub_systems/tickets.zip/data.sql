INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES
(0, 'tickets', '*', 'acl'),
(0, 'tickets_root', 'root', 'acl');

INSERT INTO `users_groups` (`g_id`, `g_name`) VALUES
(0, 'manager');


INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES
(137, 'درخواست ها', 'tickets', 'root', NULL),
(0, 'مدیریت بخش ها', 'tickets/ticket_segments', 'root', 137),
(0, 'درخواست ها', 'tickets', 'manager', NULL),
(0, 'درخواست ها', 'tickets', 'users', NULL),
(0, 'مشاهده درخواست', 'tickets/track', 'users', NULL),
(0, 'مشاهده درخواست', 'tickets/track', 'manager', NULL),
(0, 'ایجاد درخواست', 'tickets/send_ticket', 'users', NULL),
(0, 'پیغام ها', '/message/management', 'manager', NULL);
