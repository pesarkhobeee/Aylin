<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['upload_button'] = 'Завантажити файли';
$lang['upload-drop-area'] = 'Перетягнить сюди файли, щоб завантажити їх';
$lang['upload-cancel'] = 'Скасувати';
$lang['upload-failed'] = 'Не вдалося завантажити';

$lang['loading'] = 'Завантаження, зачекайте, будь ласка...';
$lang['deleting'] = 'Видалення, зачекайте, будь ласка...';
$lang['saving_title'] = 'Збереження описання...';

$lang['list_delete'] = 'Видалити';
$lang['alert_delete'] = 'Ви впевнені, що бажаєте видалити це зображення?';

/* End of file ukrainian.php */
/* Location: ./assets/image_crud/languages/ukrainian.php */