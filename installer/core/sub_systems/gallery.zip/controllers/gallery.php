<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class gallery extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		/* Standard Libraries */
		$this->load->database();
		/* ------------------ */
		
		$this->load->helper('url'); //Just for the examples, this is not required thought for the library
		
		$this->load->library('image_CRUD');
	}
	
	function _example_output($output = null)
	{
		$this->load->view('gallery/gallery',$output);	
	}
	
	function index()
	{

		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
			
		$this->load->library('grocery_CRUD');
		$crud = new grocery_CRUD();
 
        $crud->set_table('gallery_category');
        $crud->display_as('name','گالری');
        $crud->set_theme('datatables');
        $crud->add_action('مدیریت عکس ها', '', 'gallery/managment','ui-icon-plus');
        $output = $crud->render();
 
		
 
		$this->load->view('admin_them/header');
        $this->load->view('our_template.php',$output);       
        $this->load->view('admin_them/footer'); 
	}	

	public function  gallery_list()
	{
		$data["gallery_category"] = $this->db->get("gallery_category");
		$this->load->view('header');
		$this->load->view('gallery/gallery_list',$data);
		$this->load->view('footer');
	}
	
	function  show($id=null)
	{
		if($id==null)
		 return;
		 
		$image_crud = new image_CRUD();
		
		$image_crud->set_primary_key_field('id');
		$image_crud->set_url_field('url');
		$image_crud->set_table('gallery')
			->set_relation_field('gallery_category_id')
			->set_image_path('assets/uploads/gallery');
		
		$image_crud->unset_delete();
		$image_crud->unset_upload();
		$output = $image_crud->render();
		
		$this->load->view('header');
		$this->_example_output($output);
		$this->load->view('footer');
	}

	function managment($id=null)
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
			
		if($id==null)
		 return;
		 
		$image_crud = new image_CRUD();
	
		$image_crud->set_primary_key_field('id');
		$image_crud->set_url_field('url');
		$image_crud->set_title_field('title');
		$image_crud->set_table('gallery')
		->set_relation_field('gallery_category_id')
		->set_ordering_field('priority')
		->set_image_path('assets/uploads/gallery');
			
		$output = $image_crud->render();
	
		$this->load->view('admin_them/header');
		$this->_example_output($output);
		$this->load->view('admin_them/footer');
	}
	
}
