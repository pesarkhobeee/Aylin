INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES
(0, 'gallery', 'root', 'acl');



--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES
(0, 'گالری', 'gallery', 'root', NULL),
(0, 'گالری', 'gallery/gallery_list', 'public', NULL);

