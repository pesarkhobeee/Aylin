<?php
		echo "<ul style='direction:rtl;text-align:right;padding-right:30px;'>";
		foreach($gallery_category->result() as $item)
		{
			echo "<li>".anchor("gallery/show/".$item->id , $item->name)."</li>";
		}
		echo "</ul>";
