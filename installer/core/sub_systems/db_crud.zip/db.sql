
--
-- Database: `roozbeh3`
--

-- --------------------------------------------------------

--
-- Table structure for table `_fields_config`
--

CREATE TABLE IF NOT EXISTS `_fields_config` (
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `label` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `view` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='This table is for store some informations about fields of ta';

-- --------------------------------------------------------

--
-- Table structure for table `_relation_config`
--

CREATE TABLE IF NOT EXISTS `_relation_config` (
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `label` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='جدول ذخیره سازی نحوه نمایش اطلاعات جداول در کلید خارجی';

-- --------------------------------------------------------

--
-- Table structure for table `_tables_config`
--

CREATE TABLE IF NOT EXISTS `_tables_config` (
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `label` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `view` tinyint(1) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='This table is for store some informations about tables of th';
