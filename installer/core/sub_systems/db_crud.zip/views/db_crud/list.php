<ul style="direction:rtl;text-align:right;">
<?php

		foreach($tables->result() as $table)
		{
		echo "<li>".anchor('db_crud/show/' . $table->name,$table->label)."</li>";
		}
?>
</ul>
