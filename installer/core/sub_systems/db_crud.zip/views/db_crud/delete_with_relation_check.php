<div style='direction:rtl;twxt-align:right;'>
<?php
if(isset($table_name))
{
	foreach($table_name as $items)
	{
		echo "در جدول  ";
		echo anchor("db_crud/show/".$items[0],$items[1],array("target"=>"_blank"));
		echo " دارای اطلاعات مرتبط است.";
		echo "<br>"; 
		 
	}
echo "<hr>";
echo "متاسفانه تا زمان موجود بودن روابط قادر به حذف رکورد مورد نظر نیستیم";
}

if(isset($succeed))
{
		echo "<div style='direction:rtl;text-align:right;' class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
         $succeed</div>";
}

if(isset($error))
{
	echo "<div style='direction:rtl;text-align:right;' class='fade in alert alert-error'>
        <a data-dismiss='alert' class='close'>×</a>
         $error</div>";
}
?>
</div>
