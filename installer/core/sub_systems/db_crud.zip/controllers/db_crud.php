<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class db_crud extends CI_Controller {


	public function __construct()
	{
	            parent::__construct();
	            // Your own constructor code
	            //$this->output->enable_profiler(TRUE);
	            $this->load->library('grocery_CRUD');
	     
	}
	
    function show($name=NULL){
	    $this->aylin->login_check();
        
        if(!in_array($name,array("add","edit")))
        {
			if($name==NULL)
			{
				$table_name="main_persons";
			}else{
				$table_name=$name;
			}
			
			$this->session->set_userdata("table_name",$table_name);
		}
		else
		{
			$table_name = $this->session->userdata('table_name');
		}
		
	
			
		
		
	
		$crud = new grocery_CRUD();
		$crud->set_table($table_name);
		$crud->set_theme('datatables');
		
		
		$fields = $this->db->list_fields($table_name);

		
		$conter=0;

		foreach ($fields as $field)
		{
		   //echo $field;
		   
			//$this->load->database();
			$this->db->from('_fields_config');
			$this->db->where('name', $table_name.".".$field);
			$query= $this->db->get();
            $row = $query->row();
            
            if($query->num_rows()!=0)
            {
		       $crud->display_as($field,$row->label);
		       
		       if($row->view==0)
		       {
				    $unset_field[] = $field;
				    $conter = $conter + 1;
			    }
			    
			    if($field == "upload")
			    {
					$crud->set_field_upload('upload','assets/uploads/files');
				}
            }
		} 
		
		if(isset($unset_field))
    		$crud->unset_columns(implode(",",$unset_field));
    		
    		
    	//relation
    	
    	$sql = "SELECT COLUMN_NAME AS \"Foreign_Key\", REFERENCED_TABLE_NAME AS \"Ref_Table\", CONCAT( REFERENCED_TABLE_NAME, '.', REFERENCED_COLUMN_NAME ) AS \"Ref_Column\"
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_NAME IS NOT NULL
AND TABLE_NAME = '".$table_name."'";

		$query = $this->db->query($sql);
		if ($query->num_rows() > 0)
		{
			foreach ($query->result() as $row)
			{
				$this->db->where("name",$row->Ref_Table);
				$relation = $this->db->get("_relation_config");
				if ($relation->num_rows() > 0)
				{
					$relation_row = $relation->row();
					$crud->set_relation($row->Foreign_Key,$row->Ref_Table,$relation_row->label,null,$row->Foreign_Key.' DESC');
				}else{
					$crud->set_relation($row->Foreign_Key,$row->Ref_Table,'name');
				}
					
			}
    	}
    		
    		
    		
    	
    	//$crud->order_by('','desc');	
    	//$crud->callback_delete(array($this,'delete_checker'));
		
		$output = $crud->render();
		$this->_example_output($output);
	
		 
		
	}
	
	function index()
	{
		$this->aylin->login_check();
		
		$this->db->where("view","1");
		$data["tables"]= $this->db->get('_tables_config');
		
		$this->load->view('admin_them/header');
		$this->load->view('db_crud/list',$data);
		$this->load->view('admin_them/footer');
	}
	
	function table_setting()
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
			
		$this->_check_new_table();
						
		$crud = new grocery_CRUD();
		$crud->set_table('_tables_config');
        $crud->display_as('name','نام جدول');
        $crud->display_as('label','عنوان');
        $crud->display_as('view','نمایش');
        $crud->unset_delete();
        $crud->unset_add();
        
        $crud->set_theme('datatables');
        
        $crud->add_action('فیلدهای جدول', '', 'db_crud/field_setting','ui-icon-plus');
        
        $output = $crud->render();
 
        $this->_example_output($output);			
	}	
	
	function _check_new_table()
	{
		$tables = $this->db->list_tables();
		foreach ($tables as $table)
		{
			$this->db->where("name",$table);
			$query = $this->db->get("_tables_config");
			if ($query->num_rows() == 0)
			{
				$data = array(
				   'name' => $table ,
				   'label' => $table ,
				   'view' => 0
				);

				$this->db->insert('_tables_config', $data); 
			}
		} 
	}
	
	function field_setting($table_name=NULL)
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
			
		if($table_name!==NULL)
		{
			$this->_check_new_field($table_name);
			
			$crud = new grocery_CRUD();
			$crud->set_table('_fields_config');
			$crud->like("name",$table_name.'.', 'after');
			$crud->display_as('name','نام جدول');
			$crud->display_as('label','عنوان');
			$crud->display_as('view','نمایش');
			$crud->unset_delete();
			$crud->unset_add();
			
			$crud->set_theme('datatables');
			
			$output = $crud->render();
	 
			$this->_example_output($output);			
		}
	}
	
	function _check_new_field($table_name=NULL)
	{
		if($table_name!==NULL)
		{
			$fields = $this->db->list_fields($table_name);

			foreach ($fields as $field)
			{
				$this->db->where("name",$table_name.".".$field);
				$query = $this->db->get("_fields_config");
				if ($query->num_rows() == 0)
				{
					$data = array(
					   'name' => $table_name.".".$field ,
					   'label' => $field ,
					   'view' => 0
					);

					$this->db->insert('_fields_config', $data); 
				}
			} 
		}
	}

	function relation_setting()
	{
			$this->aylin->login_check();
			if(!$this->aylin->acl_check($this->uri->segment(1)))
				redirect('/users/login', 'refresh');
							
			$crud = new grocery_CRUD();
			$crud->set_table('_relation_config');
			$crud->display_as('name','نام جدول');
			$crud->display_as('label','عنوان');
			
			$crud->set_relation('name','_tables_config','name');
			
			$crud->set_theme('datatables');
			
			$output = $crud->render();
	 
			$this->_example_output($output);	
		
		
	}
		
	
	
	function _example_output($output = null)
    {
		$this->load->view('admin_them/header');
		$this->load->view('our_template.php',$output);
		$this->load->view('admin_them/footer');
            
    }	
	
}
