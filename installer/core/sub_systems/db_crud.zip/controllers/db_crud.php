<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class db_crud extends CI_Controller {


	public function __construct()
	{
	            parent::__construct();
	            // Your own constructor code
	            //$this->output->enable_profiler(TRUE);
	            $this->load->library('grocery_CRUD');
	     
	}
	
    function show($table_name=NULL)
    {
	    $this->aylin->login_check();
        
        if(!in_array($table_name,array("add","edit")))
        {
			if($table_name==NULL)
				return;
				
			$this->session->set_userdata("table_name",$table_name);
		}
		else
		{
			$table_name = $this->session->userdata('table_name');
		}
		
	
			
		
		
	
		$crud = new grocery_CRUD();
		$crud->set_table($table_name);
		$crud->set_theme('datatables');
		
		
		$fields = $this->db->list_fields($table_name);

		
		$conter=0;

		foreach ($fields as $field)
		{
		   //echo $field;
		   
			//$this->load->database();
			$this->db->from('_fields_config');
			$this->db->where('name', $table_name.".".$field);
			$query= $this->db->get();
            $row = $query->row();
            
            if($query->num_rows()!=0)
            {
		       $crud->display_as($field,$row->label);
		       
		       if($row->view==0)
		       {
				    $unset_field[] = $field;
				    $conter = $conter + 1;
			    }
			    
			    if($field == "upload")
			    {
					$crud->set_field_upload('upload','assets/uploads/files');
				}
            }
		} 
		
		if(isset($unset_field))
    		$crud->unset_columns(implode(",",$unset_field));
    		
    		
    	//relation
    	
    	$sql = "SELECT COLUMN_NAME AS \"Foreign_Key\", REFERENCED_TABLE_NAME AS \"Ref_Table\", CONCAT( REFERENCED_TABLE_NAME, '.', REFERENCED_COLUMN_NAME ) AS \"Ref_Column\"
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_NAME IS NOT NULL
AND TABLE_NAME = '".$table_name."'";

		$query = $this->db->query($sql);
		if ($query->num_rows() > 0)
		{
			foreach ($query->result() as $row)
			{
				$this->db->where("name",$row->Ref_Table);
				$relation = $this->db->get("_relation_config");
				if ($relation->num_rows() > 0)
				{
					$relation_row = $relation->row();
					$crud->set_relation($row->Foreign_Key,$row->Ref_Table,$relation_row->label,null,$row->Foreign_Key.' DESC');
				}else{
					$crud->set_relation($row->Foreign_Key,$row->Ref_Table,'name');
				}
					
			}
    	}
    		
    		
    		
    	
    	//$crud->order_by('','desc');	
		
		if($this->aylin->config("delete_with_relation_check","config_db_crud")==1)
		{
			$crud->unset_delete();
			$crud->add_action('حذف', '', 'db_crud/delete_with_relation_check/'.$table_name,'');
		}
		
		
		$output = $crud->render();
		$this->_example_output($output);
	
		 
		
	}
	
	function index()
	{
		$this->aylin->login_check();
		
		$this->db->where("view","1");
		$data["tables"]= $this->db->get('_tables_config');
		
		$this->load->view('admin_them/header');
		$this->load->view('db_crud/list',$data);
		$this->load->view('admin_them/footer');
	}
	
	function table_setting()
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
			
		$this->_check_new_table();
						
		$crud = new grocery_CRUD();
		$crud->set_table('_tables_config');
        $crud->display_as('name','نام جدول');
        $crud->display_as('label','عنوان');
        $crud->display_as('view','نمایش');
        $crud->unset_delete();
        $crud->unset_add();
        
        $crud->set_theme('datatables');
        
        $crud->add_action('فیلدهای جدول', '', 'db_crud/field_setting','ui-icon-plus');
        
        $output = $crud->render();
 
        $this->_example_output($output);			
	}	
	
	function _check_new_table()
	{
		$tables = $this->db->list_tables();
		foreach ($tables as $table)
		{
			$this->db->where("name",$table);
			$query = $this->db->get("_tables_config");
			if ($query->num_rows() == 0)
			{
				$data = array(
				   'name' => $table ,
				   'label' => $table ,
				   'view' => 0
				);

				$this->db->insert('_tables_config', $data); 
			}
		} 
	}
	
	function field_setting($table_name=NULL)
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
			
		if($table_name!==NULL)
		{
			$this->_check_new_field($table_name);
			
			$crud = new grocery_CRUD();
			$crud->set_table('_fields_config');
			$crud->like("name",$table_name.'.', 'after');
			$crud->display_as('name','نام جدول');
			$crud->display_as('label','عنوان');
			$crud->display_as('view','نمایش');
			$crud->unset_delete();
			$crud->unset_add();
			
			$crud->set_theme('datatables');
			
			$output = $crud->render();
	 
			$this->_example_output($output);			
		}
	}
	
	function _check_new_field($table_name=NULL)
	{
		if($table_name!==NULL)
		{
			$fields = $this->db->list_fields($table_name);

			foreach ($fields as $field)
			{
				$this->db->where("name",$table_name.".".$field);
				$query = $this->db->get("_fields_config");
				if ($query->num_rows() == 0)
				{
					$data = array(
					   'name' => $table_name.".".$field ,
					   'label' => $field ,
					   'view' => 0
					);

					$this->db->insert('_fields_config', $data); 
				}
			} 
		}
	}

	function relation_setting()
	{
			$this->aylin->login_check();
			if(!$this->aylin->acl_check($this->uri->segment(1)))
				redirect('/users/login', 'refresh');
							
			$crud = new grocery_CRUD();
			$crud->set_table('_relation_config');
			$crud->display_as('name','نام جدول');
			$crud->display_as('label','عنوان');
			
			$crud->set_relation('name','_tables_config','name');
			
			$crud->set_theme('datatables');
			
			$output = $crud->render();
	 
			$this->_example_output($output);	
		
		
	}
		
	
	
	function _example_output($output = null)
    {
		$this->load->view('admin_them/header');
		$this->load->view('our_template.php',$output);
		$this->load->view('admin_them/footer');
            
    }
    
	function delete_with_relation_check($tablename=NULL,$id=null)
	{

		if($id===null || $tablename===NULL)
			return;
		
		
		//find table primary key	
		$fields = $this->db->field_data($tablename);
		foreach ($fields as $field)
		{
		   if($field->primary_key==1)
			$primary_key = $field->name;
		} 

		//find all relation to this table and check this relation for specified record
		$sql = 'SELECT COLUMN_NAME AS "Foreign_Key", TABLE_NAME AS "table_name"
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_NAME IS NOT NULL
AND REFERENCED_TABLE_SCHEMA= "'.$this->db->database.'" AND REFERENCED_TABLE_NAME = "'.$tablename.'" ';

		$query = $this->db->query($sql);
		if ($query->num_rows() > 0)
		{
			$conter=0;
		   foreach ($query->result() as $row)
		   {
			  $sql2="select * from ".$row->table_name." where ".$row->Foreign_Key." = ".$id;
			  $query2 = $this->db->query($sql2);
			  if ($query2->num_rows() > 0)
			  {
						  //show all relation with specified record
						  $this->db->where("name",$row->table_name);
						  $tables_label = $this->db->get('_tables_config');
						  $tables_label_row = $tables_label->row();
						  $data["table_name"][]=array($row->table_name ,$tables_label_row->label);
						  $conter++;
			  }
			  
		   }
		   
		   if($conter==0)
		   {
			   	$this->db->where($primary_key , $id);
				if($this->db->delete($tablename))
				{
					$data["succeed"]="رکورد موردنظر با موفقیت حذف گردید";
				}else{
					$data["error"]="متاسفانه در حذف رکورد موردنظر مشکلی پیش آمده";
				}
		   }
		}
		else
		{
			$this->db->where($primary_key , $id);
			if($this->db->delete($tablename))
			{
				$data["succeed"]="رکورد موردنظر با موفقیت حذف گردید";
			}else{
				$data["error"]="متاسفانه در حذف رکورد موردنظر مشکلی پیش آمده";
			}

		}
		
	$this->load->view('admin_them/header');
	$this->load->view('db_crud/delete_with_relation_check',$data);
	$this->load->view('admin_them/footer');
	}
}
