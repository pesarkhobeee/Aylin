INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES
(0, 'db_crud', 'root', 'acl');

--
-- Dumping data for table `menu`
--
INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES
(60, 'مدیریت داده های جداول', 'db_crud/index', 'root', NULL),
(33, 'مدیریت جداول', 'db_crud/table_setting', 'root', 60),
(34, 'مدیریت کلید خارجی', 'db_crud/relation_setting', 'root', 60);
