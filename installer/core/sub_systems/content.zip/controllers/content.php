<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Content extends CI_Controller {
		// extends CI_Controller for CI 2.x users

	public $data 	= 	array();
	public function __construct()
	       {
	            parent::__construct();
	            // Your own constructor code
	           
	            $this->aylin->login_check();
						if(!$this->aylin->acl_check($this->uri->segment(1)))
							redirect('/users/login', 'refresh');
		
		$this->load->helper('url'); //You should autoload this one ;)
		$this->load->helper('ckeditor');
 
 
		//Ckeditor's configuration
		$this->data['ckeditor'] = array(
 
			//ID of the textarea that will be replaced
			'id' 	=> 	'content',
			'path'	=>	'assets/ckeditor',

 
			//Replacing styles from the "Styles tool"
			'styles' => array(
 
				//Creating a new style named "style 1"
				'style 1' => array (
					'name' 		=> 	'Blue Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 	=> 	'Blue',
						'font-weight' 	=> 	'bold'
					)
				),
 
				//Creating a new style named "style 2"
				'style 2' => array (
					'name' 	=> 	'Red Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 		=> 	'Red',
						'font-weight' 		=> 	'bold',
						'text-decoration'	=> 	'underline'
					)
				)				
			)
		);
 		
 
 
	}
	       
	public function index(){
		$this->load->library('JalaliCalendar');
		
	if(isset($_POST["content_id"])){
	
		$data = array(
               	'content_title' => $_POST["content_title"],
               	'content_text' => $_POST["content_text"],
               	'content_tag' => $_POST["content_tag"]
            	);

		$this->db->where('content_id', $_POST["content_id"]);
		$this->db->update('content', $data); 
		$data['massege'] = 'Page Successfully Updated';
		
		}elseif(isset($_POST["content_title"])){
			
			if($this->db->insert('content', $_POST))
				$data['massege'] = 'New Page Successfully Added';
		}
		
		if($this->uri->segment(3)!="")
			if($this->db->delete('content', array('content_id' => $this->uri->segment(4))))
				$data['massege'] = 'Page Successfully Deleted';
				
		$data["contents"]= $this->db->get('content');
		$this->load->view('admin_them/header');
		$this->load->view('content/main',$data);
		$this->load->view('admin_them/footer');
	}
	
	
	public function add(){
		$this->load->helper('form');
		$this->load->view('admin_them/header');
		$this->load->view('content/new', $this->data);
		$this->load->view('admin_them/footer');
	}
	
	public function edit($id){
		$this->load->helper('form');
		$this->db->where('content_id', $id); 
		$this->data['query']  = $this->db->get("content");
		$this->load->view('admin_them/header');
		$this->load->view('content/edit', $this->data);
		$this->load->view('admin_them/footer');
	}
 

 


	

}
