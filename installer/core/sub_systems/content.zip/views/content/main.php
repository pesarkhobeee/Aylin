<?php
	if(isset($massege)){echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
        <strong>Well done!</strong> $massege</div>";}
?>
<?php
			echo  "<table class='table table-striped' width='100%' id='hosts'>
				<tr>
				<th>".anchor('/content/add', '<i class="icon-user"></i>', array('class' => 'btn'))."&nbsp;</th>
				<th>Title</th>
				<th>Tag</th>
				<th>Modify Date</th>
				</tr>
				";
				
			foreach ($contents->result() as $row)
			{
				echo "<tr>";
				echo "<td>".anchor('content/index/dcontent/'.$row->content_id, '<i class="icon-remove"></i>', array('class' => 'btn','tooltip'=>'Delete'))."&nbsp;".anchor('content/edit/'.$row->content_id, '<i class="icon-pencil"></i>', array('class' => 'btn','tooltip'=>'Update'))."&nbsp;"."</td>";
				echo "<td>".anchor('welcome/index/'.$row->content_title,$row->content_title,array("target"=>"_blank"))."</td>";
				echo "<td>".$row->content_tag."</td>";
				$gdate=$row->content_modify_date;
				list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
				list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
				$jdate=$jyear."-".$jmonth."-".$jday;
	                        echo  "<td><a  data-content=\"<center><h3>$jdate</h3></center>\" rel=\"popover\" href=\"#\" data-original-title=\"$gdate in jalali is\"><i class='icon-calendar'></i></a>&nbsp;".$row->content_modify_date."</td>";
				echo "</tr>";
			}
			
			echo "<table>";
		?>