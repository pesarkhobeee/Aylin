<?php
	if(isset($massege)){echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
        <strong>Well done!</strong> $massege</div>";}
?>
<?php
			echo  "<table class='table table-striped' width='100%' id='hosts'>
				<tr>
				<th>".anchor('/content/add', '<i class="icon-user"></i>', array('class' => 'btn','rel'=>'tooltip','data-original-title'=>'ایجاد'))."&nbsp;</th>
				<th>عنوان</th>
				<th>تگ ها</th>
				<th>تاریخ </th>
				</tr>
				";
				
			foreach ($contents->result() as $row)
			{
				echo "<tr>";
				echo "<td>".anchor('content/index/dcontent/'.$row->content_id, '<i class="icon-remove"></i>', array('class' => 'btn','tooltip'=>'Delete','onclick'=>'return confirm(\'آیا قصد دارید این سطر را حذف کنید؟\')','rel'=>'tooltip','data-original-title'=>'حذف'))."&nbsp;".anchor('content/edit/'.$row->content_id, '<i class="icon-pencil"></i>', array('class' => 'btn','tooltip'=>'Update','rel'=>'tooltip','data-original-title'=>'بروزرسانی'))."&nbsp;"."</td>";
				echo "<td>".anchor('welcome/index/'.$row->content_title,$row->content_title,array("target"=>"_blank"))."</td>";
				echo "<td>".$row->content_tag."</td>";
				$gdate=$row->content_modify_date;
				list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
				list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
				$jdate=$jyear."-".$jmonth."-".$jday;
	                        echo  "<td>$jdate</td>";
				echo "</tr>";
			}
			
			echo "<table>";
		?>
