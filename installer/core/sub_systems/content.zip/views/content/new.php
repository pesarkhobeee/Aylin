
<?php echo form_open('content/index'); ?>
	<label for="content_title">Title</label>
	<input type="text" name="content_title" />
	<textarea name="content_text" id="content" ></textarea>
	<?php echo display_ckeditor($ckeditor); ?>
	<label for="content_tag">Tag</label>
	<input type="text" name="content_tag" />
	<input type="submit" value="Submit Page" />
	<input type="hidden" name="content_modify_date" value="<?php echo date("Y:m:d"); ?>" />
<?php echo form_close(); ?>