<div style="direction:rtl">
<?php echo form_open('content/index'); ?>
	<label for="content_title">نام</label>
	<input type="text" name="content_title" />
	<textarea name="content_text" id="content" ></textarea>
	<?php echo display_ckeditor($ckeditor); ?>
	<label for="content_tag">تگ</label>
	<input type="text" name="content_tag" />
	<br>
	<input class="btn btn-success" type="submit" value="ثبت" />
	<input type="hidden" name="content_modify_date" value="<?php echo date("Y:m:d"); ?>" />
<?php echo form_close(); ?>
</div>
