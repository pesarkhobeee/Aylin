<?php
foreach ($query->result() as $row){
 echo form_open('content/index'); ?>
	<label for="content_title">Title</label>
	<input type="text" name="content_title" value="<?php echo $row->content_title; ?>" />
	<textarea name="content_text" id="content" >
	
	<?php echo htmlentities($row->content_text,ENT_COMPAT ,"UTF-8"); ?>
	
	</textarea>
	<?php echo display_ckeditor($ckeditor); ?>
	<label for="content_tag">Tag</label>
	<input type="text" name="content_tag" value="<?php echo $row->content_tag; ?>" />
	<input type="submit" value="Submit Page" />
	<input type="hidden" name="content_modify_date" value="<?php echo date("Y:m:d"); ?>" />
	<input type="hidden" name="content_id" value="<?php echo $row->content_id; ?>" />
	
<?php echo form_close(); 
}
?>