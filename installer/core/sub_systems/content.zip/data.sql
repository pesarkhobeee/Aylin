INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES (0, 'content', 'root', 'acl');
INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES (0, 'برگه ها', 'content', 'root',6); 
