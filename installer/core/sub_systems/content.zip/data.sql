INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES (0, 'content', 'root', 'acl');
INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`) VALUES (0, 'محتوا', 'content', 'admin'); 
