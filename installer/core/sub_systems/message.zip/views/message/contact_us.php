<ul style="direction:rtl;list-style-type:none;">
<?php
	echo form_open('message/contact_us_register');
	echo("<li>");
	echo form_label('نام ', 'name');
	echo form_input(array('id'=>'mc_name','name'=>'mc_name'));
	echo("</li><li>");
	echo form_label('پست الکترونیکی', 'mc_email');
	echo form_input(array('id'=>'mc_email','name'=>'mc_email'));
	echo("</li><li>");
	echo form_label('متن پیغام', 'mc_message');
	echo form_textarea(array("name"=>"mc_message","id"=>"mc_message","style"=>"width: 447px; height: 177px;"));
	echo("</li><li>");
	echo $image;
	echo("</li><li>");
	echo form_label('کد تصویر بالا را وارید کنید', 'mc_captcha_word');
	echo form_input(array('id'=>'captcha_word','name'=>'captcha_word'));
	echo("</li><li>");
	echo("<input type='submit' value='ثبت' class='btn' />");
	echo '<input type="hidden" name="receiver_user_id" value="7" />';
	echo("</li>");
	echo form_close();
?>

</ul>

<script src="<?php echo base_url("assets/js/jquery.validate.js"); ?>" type="text/javascript"> </script>
<script language="javascript">
	
    /* <![CDATA[ */
jQuery(function(){
             jQuery("#mc_message").validate({
                    expression: "if (VAL!='') return true; else return false;",live:false,
                    message: "&nbsp;لطفا این فیلد را پر کنید&nbsp;"                 
                });

             jQuery("#captcha_word").validate({
                    expression: "if (VAL!='') return true; else return false;",live:false,
                    message: "&nbsp;لطفا این فیلد را پر کنید&nbsp;"                 
                });
 });
/* ]]> */
    </script>    
