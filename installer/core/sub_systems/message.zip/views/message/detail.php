<?php
	foreach($message->result() as $row)
	{
		echo "
		
	<table class='table-striped' width='100%' style='direction:rtl;text-align:right;'>
	<tr>
		<td width='20%'>نام</td>
		<td>".$row->mc_name."</td>
	</tr>
	<tr>
		<td>پست الکترونیکی</td>
		<td>".$row->mc_email."</td>
	</tr>
	<tr>
		<td>تاریخ</td>
		<td>".$row->mc_create_date."</td>
	</tr>
	<tr>
		<td>پیغام</td>
		<td>".$row->mc_message."</td>
	</tr>
	</table>
		
		";
	}
