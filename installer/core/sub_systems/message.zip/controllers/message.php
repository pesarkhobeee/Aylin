<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class message extends CI_Controller 
{

	public function __construct()
       	{
	        	parent::__construct();
			$this->load->library('grocery_CRUD');
	            // Your own constructor code
		    $this->output->enable_profiler(TRUE);
	}

	function _example_output($output = null)
	{
		$this->load->view('our_template.php',$output);    
	}

	public function management()
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
		
	 	$crud = new grocery_CRUD();
		$crud->set_relation('receiver_user_id','message_section','ms_name');

        	$crud->set_table('message_contact_us');
       		$crud->display_as('mc_name','نام');
		$crud->display_as('mc_email','پست الکترونیکی');
		$crud->display_as('mc_message','پیغام');
		$crud->display_as('receiver_user_id','مقصد');
		$crud->display_as('mc_create_date','تاریخ ارسال');
         	$crud->set_theme('datatables');
        	$output = $crud->render();
 
		$this->load->view('admin_them/header');
        	$this->_example_output($output);       
        	$this->load->view('admin_them/footer');  
	}

	public function section()
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
		
	 	$crud = new grocery_CRUD();
        	$crud->set_table('message_section');
		$crud->set_relation('users_id','users','username');

       		$crud->display_as('ms_name','نام');
		$crud->display_as('mc_email','پست الکترونیکی');
		$crud->display_as('mc_message','پیغام');
		$crud->display_as('receiver_user_id','مقصد');
		$crud->display_as('mc_create_date','تاریخ ارسال');
         	$crud->set_theme('datatables');
        	$output = $crud->render();
 
		$this->load->view('admin_them/header');
        	$this->_example_output($output);       
        	$this->load->view('admin_them/footer');  
	}

	public function index()
	{
		if($this->aylin->config("contact_us","config_message")==1)
		{
		$this->load->helper('captcha');
		$vals = array(
		    'img_path' => './assets/captcha/',
		    'img_url' => base_url('/assets/captcha/')."/",
		    'img_width' => '150',
		    'img_height' => 30
		    );

		$cap = create_captcha($vals);
		$this->session->set_userdata(array('captcha_word' => $cap['word']));
			

			$this->load->helper('form');
			$this->load->view('header');
			$this->load->view('message/contact_us',$cap);
			$this->load->view('footer');
		}

	}

	public function contact_us_register()
	{
		if($this->aylin->config("contact_us","config_message")==1)
		{
				
			$this->load->library('form_validation');
			$this->form_validation->set_rules('mc_message', 'Massage', 'trim|required');
			$this->form_validation->set_rules('captcha_word', 'captcha_word', 'trim|required');
			if ($this->form_validation->run() == FALSE)
			{
				$data["error"]="لطفا همه فیلد های فرم را پر کنید";
			}
			else
			{
				if(strtolower($_POST["captcha_word"])==strtolower($this->session->userdata('captcha_word')))
				{
					unset($_POST["captcha_word"]);
					$_POST["mc_create_date"]=date("Y-m-d");

					if(!$this->db->insert('message_contact_us', $_POST))
					{
						$data['error'] = 'متاسفانه در ارسال پیغام شما مشکلی پیش آمد';
					}
					else
					{
						$data['massege'] = 'کاربر گرامی، پیغام شما با موفقیت ارسال شد';
					}
				}
				else
				{
					$data['error'] = 'کد تصویر وارد شده صحیح نمیباشد';
				}
			}

			$this->load->view('header');
			$this->load->view('message/contact_us_register',$data);
			$this->load->view('footer');


		}
	}




}
