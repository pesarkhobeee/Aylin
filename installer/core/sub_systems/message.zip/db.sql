--
-- Table structure for table `message_contact_us`
--

CREATE TABLE IF NOT EXISTS `message_contact_us` (
  `mc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mc_name` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `mc_email` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `mc_message` text COLLATE utf8_persian_ci NOT NULL,
  `receiver_user_id` int(10) unsigned NOT NULL,
  `mc_create_date` date NOT NULL,
  PRIMARY KEY (`mc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `message_section`
--

CREATE TABLE IF NOT EXISTS `message_section` (
  `ms_name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `users_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;
