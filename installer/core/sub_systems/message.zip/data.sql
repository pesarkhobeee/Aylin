--
-- Dumping data for table `meta_data`
--

INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES
(0, 'contact_us', '1', 'config_message'),
(0, 'message', 'root', 'acl');



--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES

(0, 'ارتباط با ما', 'message', 'public', NULL),
(12, 'پیغام ها', 'message/management', 'root', NULL),
(0, 'مدیریت بخش ها', 'message/section', 'root', 12);



--
-- Dumping data for table `message_section`
--

INSERT INTO `message_section` (`ms_name`, `users_id`) VALUES
('مدیر سایت', 7);

