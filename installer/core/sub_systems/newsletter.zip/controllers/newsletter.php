<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class newsletter extends CI_Controller {
		// extends CI_Controller for CI 2.x users
		
		public function __construct()
	       {
	            parent::__construct();
	            // Your own constructor code
	          
	            $this->load->library('Z_auth');
	            $this->z_auth->login_check();
						if(!$this->z_auth->acl_check($this->uri->segment(1)))
							redirect('/users/login', 'refresh');
				
				
		
	}

	function index(){
		

		
		$this->load->helper('url'); //You should autoload this one ;)
		$this->load->helper('ckeditor');
 
 
		//Ckeditor's configuration
		$data['ckeditor'] = array(
 
			//ID of the textarea that will be replaced
			'id' 	=> 	'content',
			'path'	=>	'assets/ckeditor',

 
			//Replacing styles from the "Styles tool"
			'styles' => array(
 
				//Creating a new style named "style 1"
				'style 1' => array (
					'name' 		=> 	'Blue Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 	=> 	'Blue',
						'font-weight' 	=> 	'bold'
					)
				),
 
				//Creating a new style named "style 2"
				'style 2' => array (
					'name' 	=> 	'Red Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 		=> 	'Red',
						'font-weight' 		=> 	'bold',
						'text-decoration'	=> 	'underline'
					)
				)				
			)
		);
		
		$this->load->helper('form');
		
		$this->db->select("g_name");
		$data["user_groups"]= $this->db->get('users_groups');
		
		$this->load->view('admin_them/header');
		$this->load->view('newsletter/index', $data);
		$this->load->view('admin_them/footer');
	}
	
	function newsletter_members(){
		$this->load->helper('form');
		
		if(isset($_POST["nm_id"])){
			$this->db->where('nm_id', $_POST["nm_id"]);
			print_r($_POST);
			if($this->db->update('newsletter_members', $_POST))
				$data['massege'] = 'newsletter member Successfully Updated';
		}elseif(isset($_POST["nm_name"])){
				if($this->db->insert('newsletter_members', $_POST))
					$data['massege'] = 'New newsletter member Successfully Added';
		}
		
		
		if($this->uri->segment(3)!="")
			if($this->uri->segment(3)=="d")
				if($this->db->delete('newsletter_members', array('nm_id' => $this->uri->segment(4))))
					$data['massege'] = 'newsletter member Successfully Deleted';
		
		$data["query"]= $this->db->get('newsletter_members');
		$this->load->view('admin_them/header');
		$this->load->view('newsletter/newsletter_members', $data);
		$this->load->view('admin_them/footer');
	}
	
	function send(){
	if(isset($_POST["send_group"]))
	{	

		$emails=array();
		if($_POST["send_group"][0]=="all")
		{
			$this->db->select('username');
			$query = $this->db->get("users");
			foreach ($query->result() as $row)
			 {
				array_push($emails,$row->username);
				 
			 }
			 
			$query = $this->db->get("newsletter_members");
			foreach ($query->result() as $row)
			 {
				 array_push($emails,$row->nm_mail);
			 }
			 
			 
		}
		else
		{
			if(in_array("newsletter_members",$_POST["send_group"]))
			{
				$query = $this->db->get("newsletter_members");
				foreach ($query->result() as $row)
				 {
					 array_push($emails,$row->nm_mail);
				 }
				 
				 $k = array_search("newsletter_members",$_POST["send_group"]);				 
				 unset($_POST["send_group"][$k]);
				 
			 }
			 
			$this->db->select('username');
			foreach($_POST["send_group"] as $send_group)
			{
				$query = $this->db->get_where("users",array("user_group"=>$send_group));
				foreach ($query->result() as $row)
				 {
					array_push($emails,$row->username);
				 }
			}
		}
		
			

		$content=$_POST["title"];
		$to=$emails;
		if($this->aylin_config->send_mail($_POST["content"],$content,$to,"bcc"))
			$data["msg"] = "<p><b>خبرنامه با موفقیت ارسال شد</b></p>";
		else
			$data["error"] = "<p><b>متاسفانه در ارسال خبرنامه مشکلی پیش آمد</b></p>";

		
		$this->load->view('admin_them/header');
		$this->load->view('newsletter/send', $data);
		$this->load->view('admin_them/footer');
		

	}
	}	
}
