 INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES (0, 'خبرنامه', 'newsletter', 'root', 6);
 INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES (0, 'enable_newslater_in_news', '1', 'config_site');
 INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES (0, 'newsletter', 'root', 'acl');
