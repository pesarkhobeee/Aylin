CREATE TABLE IF NOT EXISTS `newsletter_members` (
  `nm_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nm_name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `nm_mail` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`nm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=0 ;
 
