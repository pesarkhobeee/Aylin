 
<?php
			if(isset($massege)){echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
        <strong>Well done!</strong> $massege</div>";}
?>

    <div class="modal fade" id="group">
    	<div class="modal-header">
    		<a class="close" data-dismiss="modal">×</a>
   		 <h3>ایجاد کاربر</h3>
		</div>
    	<div class="modal-body">

			<ul style="list-style-type:none;direction:rtl;list-style-type:none;" >
				<?php
					echo form_open('newsletter/newsletter_members',array('id'=>'newsletter_members_form'));
					echo("<li>");
					echo form_label('نام ', 'nm_name');
					echo form_input('nm_name');
					echo("<li></li>");
					echo form_label('پست الکترونیکی ', 'nm_mail');
					echo form_input('nm_mail');					
					echo("</li>");
					echo form_close();
				?>
				</ul>
		</div>
		<div class="modal-footer">
			 <a href="#" onclick="document.getElementById('newsletter_members_form').submit()" class="btn btn-primary">ثبت</a>
		 <a href="#" class="btn" data-dismiss="modal">Close</a>
		</div>
    </div>	
 
 
    <div class="modal fade" id="update">
    	<div class="modal-header">
    		<a class="close" data-dismiss="modal">×</a>
   		 <h3>بروز رسانی </h3>
   	</div>
    	<div class="modal-body">

	<ul style="direction:rtl;list-style-type:none;">
		<?php
			echo form_open('newsletter/newsletter_members',array('id'=>'update_newsletter_members'));
			echo "<input type='hidden' name='nm_id' id='nm_id' />";
			echo("<li>");
			echo form_label('نام ', 'nm_name');
			echo form_input(array('name'=>'nm_name','id'=>'nm_name'));
			echo("<li></li>");
			echo form_label('پست الکترونیکی', 'mail');
			echo form_input(array('name'=>'nm_mail','id'=>'nm_mail'));					
			echo("</li>");
			echo form_close();
		?>
		</ul>

  	</div>
    <div class="modal-footer">
    	 <a href="#" onclick="document.getElementById('update_newsletter_members').submit()" class="btn btn-primary">بروزرسانی</a>
   	 <a href="#" class="btn">Close</a>
    </div>
    </div>
 
 
   
		<?php
			echo  "<table class='table table-striped' width='100%' >
				<tr>
				<th>".anchor('#group', '<i class="icon-pencil"></i>', array('class' => 'btn','data-toggle'=>'modal'))."&nbsp;</th>
				<th>نام</th>
				<th>پست الکترونیک</th>
				</tr>
				";
				
			foreach ($query->result() as $row)
			{
				echo "<tr>";
				echo "<td>".anchor('newsletter/newsletter_members/d/'.$row->nm_id, '<i class="icon-remove"></i>', array('class' => 'btn','tooltip'=>'Delete','onclick'=>'return confirm(\'آیا قصد دارید این سطر را حذف کنید؟\')'))."&nbsp;<a href='#update' class='btn' data-toggle='modal' onclick='document.getElementById(\"nm_id\").value=".$row->nm_id.";document.getElementById(\"nm_name\").value=\"".$row->nm_name."\";document.getElementById(\"nm_mail\").value=\"".$row->nm_mail."\"'><i class='icon-pencil' ></i></a>&nbsp;"."</td>";
				echo "<td>".$row->nm_name."</td>";
				echo "<td>".$row->nm_mail."</td>";
				echo "</tr>";
			}
			
			echo "<table>";
		?> 
