<style>
	#newsletter li{
		margin-top:5px;
	}
</style>
<?php
$tmp["all"]="همه کاربران";
foreach ($user_groups->result() as $row)
{
	$tmp[$row->g_name]=$row->g_name;
}
$tmp["newsletter_members"]="کاربران غیر عضو";


$title="";
$content="";
if(isset($news))
{
	$news_show = $news->row();
	$title=$news_show->n_title;
	$content=$news_show->n_content;
}
	
echo form_open('newsletter/send');
echo "<ul id='newsletter' style='direction:rtl;list-style-type:none;'>";
echo "<li>";
echo "عنوان";
echo "</li><li>";	
echo form_input('title', $title);
echo "</li><li>";
echo "ارسال به";
echo "</li><li>";
echo form_multiselect('send_group[]',$tmp,array("all"));
echo "</li><li>";
echo anchor("newsletter/newsletter_members","مدیریت کاربران غیر عضو", array("class"=>"btn btn-success"));
echo "</li><li>";
echo "متن پیام";
echo "</li><li>";
echo form_textarea('content',$content);
echo display_ckeditor($ckeditor);
echo "</li><li>";
echo form_submit(array("class"=>"btn btn-success"),'ارسال پیام');
echo "</li>";
echo "</ul>";
echo form_close();

