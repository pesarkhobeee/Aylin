<?php
			if(isset($msg)){echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
         $msg</div>";}
?>

<?php
			if(isset($alert)){echo "<div class='fade in alert alert-warning'>
        <a data-dismiss='alert' class='close'>×</a>
       $alert</div>";}
?>
