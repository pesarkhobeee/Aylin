<?php
	if(isset($msg)){echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
        $msg</div>";}
?>

<?php
	if(isset($error)){echo "<div class='fade in alert alert-erroralert alert-error'>
        <a data-dismiss='alert' class='close'>×</a>
        $error</div>";}
?>
