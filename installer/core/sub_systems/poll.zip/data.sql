 INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES (0, 'نظرسنجی', '/polls/poll', 'root', NULL);
 INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES (0, 'public_poll', '1', 'config_poll'); 
 INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES (0, 'poll', 'root', 'acl');
