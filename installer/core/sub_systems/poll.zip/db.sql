--
-- Table structure for table `poll_choice`
--

CREATE TABLE IF NOT EXISTS `poll_choice` (
  `c_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_poll_id` int(10) unsigned NOT NULL,
  `c_poll_choice` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `c_votes` int(10) unsigned NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `poll_poll`
--

CREATE TABLE IF NOT EXISTS `poll_poll` (
  `p_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `p_question` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `p_pub_date` date NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;
