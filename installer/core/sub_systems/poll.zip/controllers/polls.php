<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class polls extends CI_Controller 
{

	
	public function __construct()
	{
      	        parent::__construct();
		//$this->output->enable_profiler(TRUE);
		$this->load->helper('form');
	    // Your own constructor code
	   
	

	}

	public function index()
	{

		if($this->session->userdata('poll')=="")
		{
			$id =$this->aylin->config("public_poll","config_poll");
			$this->db->where("p_id", $id);		
			$data["poll_poll"]= $this->db->get('poll_poll');
			$this->db->where("c_poll_id", $id);		
			$data["poll_choice"]= $this->db->get('poll_choice');
			$this->load->view('admin_them/header');
			$this->load->view('poll/poll',$data);
			$this->load->view('admin_them/footer');
		}
		else
		{
		
			$id=$this->aylin->config("public_poll","config_poll");

			$this->db->where("p_id", $id);		
			$data["poll_poll"]= $this->db->get('poll_poll');
			$this->db->where("c_poll_id", $id);		
			$data["poll_choice"]= $this->db->get('poll_choice');


			$this->db->select_sum('c_votes');
			$this->db->where("c_poll_id", $id);
			$query = $this->db->get('poll_choice');
			$data["sum"] = $query->row();

			$this->load->view('admin_them/header');
			$this->load->view('poll/poll_show',$data);
			$this->load->view('admin_them/footer');	

		}
	}
	
	public function poll()
	{

	$this->aylin->login_check();
	if(!$this->aylin->acl_check("poll"))
		redirect('/users/login', 'refresh');

		if($this->uri->segment(3)!="")
		{
			if($this->uri->segment(3)=="dpoll")
			{
				if($this->db->delete('poll_choice', array('c_poll_id' => $this->uri->segment(4))))
					if($this->db->delete('poll_poll', array('p_id' => $this->uri->segment(4))))
						$data['massege'] = 'Page Successfully Deleted';
			}
			else
			{
				$this->db->where('group','config_poll');
				$this->db->where('name','public_poll');
				if($this->db->update('meta_data', array("value"=>$this->uri->segment(4))))
						$data['massege'] = 'POLL Successfully puliced';
			}
		}

		if(isset($_POST["p_id"]))
		{
			$data = array(
		       	'p_question' => $_POST["p_question"]
			);

			$this->db->where('p_id', $_POST["p_id"]);
			if($this->db->update('poll_poll', $data))
			{

				for($i=0;$i<count($_POST["c_poll_choice"]);$i++)
				{	$data2[] = array(
					       	'c_poll_choice' => $_POST["c_poll_choice"][$i],
						'c_id' => $_POST["c_id"][$i]
					);
				}

				$this->db->update_batch('poll_choice', $data2, 'c_id');
				$data['massege'] = 'Page Successfully Updated';

			}

		}
		elseif(isset($_POST["p_question"]))
		{
			$poll_poll = array(
			   'p_question' => $_POST["p_question"] ,
			   'p_pub_date' => date("Y-m-d") 
			);
			$this->db->insert('poll_poll', $poll_poll);

			$id = $this->db->insert_id();

			for($i=0;$i<count($_POST["c_poll_choice"]);$i++)
			{
				$poll_choice[] = array(
				   'c_poll_id' => $id  ,
				   'c_poll_choice' => $_POST["c_poll_choice"][$i]  ,
				   'c_votes' => 0 
				);
				
			}

			if($this->db->insert_batch('poll_choice', $poll_choice))
			{
	
				$data['massege'] = 'New poll Successfully Added';
			}

		}


		$this->load->library('JalaliCalendar');	
		$this->db->order_by("p_id", "desc");		
		$data["contents"]= $this->db->get('poll_poll');
		$this->load->view('admin_them/header');
		$this->load->view('poll/main',$data);
		$this->load->view('admin_them/footer');
	}


	public function add()
	{

	$this->aylin->login_check();
	if(!$this->aylin->acl_check("poll"))
		redirect('/users/login', 'refresh');
	
		$this->load->view('admin_them/header');
		$this->load->view('poll/add');
		$this->load->view('admin_them/footer');
	}


	public function poll_submit()
	{

		$this->session->set_userdata(array("poll"=>"true"));
		$this->db->where('c_id', $_POST["c_id"]);
		$query= $this->db->get("poll_choice");
		$row = $query->row();
		$vote= 	$row->c_votes + 1 ;
	
		$data = array(
	       		'c_votes' => $vote
		);
		$this->db->where('c_id', $_POST["c_id"]);
		$this->db->update('poll_choice', $data);
		$id =$_POST["p_id"];
		$this->db->where("p_id", $id);		
		$data["poll_poll"]= $this->db->get('poll_poll');
		$this->db->where("c_poll_id", $id);		
		$data["poll_choice"]= $this->db->get('poll_choice');


		$this->db->select_sum('c_votes');
		$this->db->where("c_poll_id", $id);
		$query = $this->db->get('poll_choice');
		$data["sum"] = $query->row();
		


		//$this->load->view('admin_them/header');
		$this->load->view('poll/poll_show',$data);
		//$this->load->view('admin_them/footer');	

	}


	public function edit($id)
	{
	
	$this->aylin->login_check();
	if(!$this->aylin->acl_check("poll"))
		redirect('/users/login', 'refresh');

		$this->db->where('p_id', $id); 
		$data['poll_poll']  = $this->db->get("poll_poll");

		$this->db->where('c_poll_id', $id); 
		$data['poll_choice']  = $this->db->get("poll_choice");

		$this->load->view('admin_them/header');
		$this->load->view('poll/edit',$data);
		$this->load->view('admin_them/footer');		
	}

	public function show($id="")
	{

	$this->aylin->login_check();
	if(!$this->aylin->acl_check("poll"))
		redirect('/users/login', 'refresh');

		if($id=="")
			$id=$this->aylin->config("public_poll","config_poll");

		$this->db->where("p_id", $id);		
		$data["poll_poll"]= $this->db->get('poll_poll');
		$this->db->where("c_poll_id", $id);		
		$data["poll_choice"]= $this->db->get('poll_choice');


		$this->db->select_sum('c_votes');
		$this->db->where("c_poll_id", $id);
		$query = $this->db->get('poll_choice');
		$data["sum"] = $query->row();

		$this->load->view('admin_them/header');
		$this->load->view('poll/poll_show',$data);
		$this->load->view('admin_them/footer');	
	}


}
