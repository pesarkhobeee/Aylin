<div style="direction:rtl;" id="poll_container">
<?php
foreach ($poll_poll->result() as $row)
{ ?>
<form name="poll" id="poll" method="post" action='' >
	<?php  echo  $row->p_question;  ?>
	<input type="hidden" name="p_id" id="p_id" value="<?php  echo  $row->p_id;  ?>" />
<br>
<?php
foreach ($poll_choice->result() as $row2)
{
?>
	<input type="radio" name="c_id" id="c_id" value="<?php echo $row2->c_id;  ?>" />
	&nbsp;
	<?php echo $row2->c_poll_choice;  ?>
	<br>
<?php
}
?>
	<br>
	<input type="submit" id="submit" value="ارسال" class="btn" />
	</form>
<?php 
}
?>
</div>


<script>
$(document).ready(function(){
	$("#submit").click(function() {

		var dataString ='p_id='+$("#p_id").val()+'&c_id='+$('input:radio[name=c_id]:checked').val();

		$.ajax({
		      type: "POST",
		      url: '<?php echo base_url().'index.php/polls/poll_submit'; ?>',
		      data:dataString,
		      success: function(result_data) {
			$('#poll_container').html(result_data);
		      },
		      error: function () {
			$('#poll_container').html("<b>متاسفانه در ارسال اطلاعات مشکلی پیش آمد</b>");
		      }
		     });

		return false;
	 });

 });
</script>
