<div style="direction:rtl;">
<?php
foreach ($poll_poll->result() as $row)
{
 echo form_open('polls/poll'); ?>
	<label for="p_question">سوال نظرسنجی</label>
	<input type="hidden" name="p_id" value="<?php  echo  $row->p_id;  ?>" />
	<input type="text" name="p_question" value="<?php  echo  $row->p_question;  ?>" />
	<hr>
<?php
foreach ($poll_choice->result() as $row2)
{
?>
	<label for="c_poll_choice1">گزینه </label>
	<input type="text" name="c_poll_choice[]" value="<?php echo $row2->c_poll_choice;  ?>" />
	<input type="hidden" name="c_id[]" value="<?php  echo  $row2->c_id;  ?>" />
	
<?php
}
?>
	<hr>
	<input type="submit" value="ثبت نظرسنجی" class="btn btn-success" />
	
<?php echo form_close(); 
}
?>
</div>
