<div style="direction:rtl;">
<?php echo form_open('polls/poll'); ?>
	<label for="p_question">سوال نظرسنجی</label>
	<input type="text" name="p_question" />
	<hr>
	<div id="poll_choice">
	<label for="c_poll_choice">گزینه </label>
	<input type="text" name="c_poll_choice[]" />
	<label for="c_poll_choice">گزینه </label>
	<input type="text" name="c_poll_choice[]" />
	<label for="c_poll_choice">گزینه </label>
	<input type="text" name="c_poll_choice[]" />
	<label for="c_poll_choice">گزینه </label>
	<input type="text" name="c_poll_choice[]" />
	</div>
	<hr>
	<input type="submit" value="ثبت نظرسنجی" class="btn btn-success" />
	<a href="#" id="add" class="btn"><i class="icon-plus"></i></a>
<?php echo form_close(); ?>
</div>
<script>
$(document).ready(function(){
	$("#add").click(function() {
		$('#poll_choice').append("<label for='c_poll_choice'>گزینه </label><input type='text' name='c_poll_choice[]' />");
		return false;
	 });

 });
</script>

