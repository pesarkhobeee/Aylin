<div style="direction:rtl;">
<?php

foreach ($poll_poll->result() as $row)
{
	  ?>
<br>
<table>
<?php
$sum = $sum->c_votes;
foreach ($poll_choice->result() as $row2)
{
?>
	<tr>
		<td>
			<?php echo $row2->c_poll_choice;  ?>
		</td>
		<td>
			<span style="height:10px;background-color:red;">
			<?php 
			
			
			$darsad =$row2->c_votes / $sum * 100;

			for($i=0;$i <= $darsad; $i=$i+10)
			{
				echo "&nbsp;";
	
			}
			  ?>
			</span>
			&nbsp;<?php echo $row2->c_votes; ?>&nbsp;
		</td>
	</tr>
	
<?php
}
?>
</table>
<br>
<?php
}
?>
</div>
