<?php
	if(isset($massege)){echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
       $massege</div>";}
?>
<?php
			echo  "<table class='table table-striped' width='100%' id='hosts'>
				<tr>
				<th>".anchor('/polls/add', '<i class="icon-user"></i>', array('class' => 'btn','rel'=>'tooltip','data-original-title'=>'ایجاد'))."&nbsp;</th>
				<th>نظرسنجی</th>
				<th>تاریخ ثبت</th>
				</tr>
				";
				
			foreach ($contents->result() as $row)
			{
				echo "<tr>";
				echo "<td>".anchor('polls/poll/dpoll/'.$row->p_id, '<i class="icon-remove"></i>', array('class' => 'btn','tooltip'=>'Delete','onclick'=>'return confirm(\'آیا قصد دارید این سطر را حذف کنید؟\')','rel'=>'tooltip','data-original-title'=>'حذف'))."&nbsp;".anchor('polls/edit/'.$row->p_id, '<i class="icon-pencil"></i>', array('class' => 'btn','tooltip'=>'Update','rel'=>'tooltip','data-original-title'=>'بروزرسانی'))."&nbsp;".anchor('polls/poll/cpoll/'.$row->p_id, '<i class="icon-ok"></i>', array('class' => 'btn','tooltip'=>'choose','onclick'=>'return confirm(\'آیا قصد دارید این نظرسنجی در صفحه اول بیاید؟\')','rel'=>'tooltip','data-original-title'=>'نمایش در صفحه اصلی'))."&nbsp;".anchor('polls/show/'.$row->p_id, '<i class="icon-eye-open"></i>', array('class' => 'btn','tooltip'=>'Show','rel'=>'tooltip','data-original-title'=>'نتایج'))."</td>";
				echo "<td>".$row->p_question."</td>";
				$gdate=$row->p_pub_date;
				list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate);
				list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
				$jdate=$jyear."-".$jmonth."-".$jday;
	                        echo  "<td>$jdate</td>";
				echo "</tr>";
			}
			
			echo "<table>";
		?>
