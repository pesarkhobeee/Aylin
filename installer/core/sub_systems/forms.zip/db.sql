
--
-- Table structure for table `forms`
--

CREATE TABLE IF NOT EXISTS `forms` (
  `f_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `f_modify_date` datetime NOT NULL,
  `f_manager` int(10) unsigned NOT NULL,
  `f_content` longtext COLLATE utf8_persian_ci NOT NULL,
  `f_attachment` tinyint(1) NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `forms_attachment`
--

CREATE TABLE IF NOT EXISTS `forms_attachment` (
  `fa_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fd_id` int(10) unsigned NOT NULL,
  `fa_address` varchar(250) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`fa_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `forms_data`
--

CREATE TABLE IF NOT EXISTS `forms_data` (
  `fd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_id` int(10) unsigned NOT NULL,
  `fd_content` longtext COLLATE utf8_persian_ci NOT NULL,
  `fd_create_date` datetime NOT NULL,
  `fd_checked` tinyint(1) NOT NULL,
  `fd_checked_date` datetime DEFAULT NULL,
  PRIMARY KEY (`fd_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=14 ;
