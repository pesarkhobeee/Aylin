<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class forms extends CI_Controller {

	public function __construct()
	{
	            parent::__construct();

				//$this->output->enable_profiler(TRUE);
	}
	
	function index()
    {
		$this->load->helper('form');
		$this->db->select("f_id,f_title");
		$data["forms"]= $this->db->get('forms');
		$this->load->view('header');
		$this->load->view('forms/main',$data);
		$this->load->view('footer');	
	}
	
	function show($f_id=NULL)
	{
			if(isset($f_id))
			{
				$this->load->helper('captcha');
				$vals = array(
					'img_path' => './assets/captcha/',
					'font_path' => './assets/fonts/AllerDisplay.ttf',
					'img_url' => base_url('/assets/captcha/')."/",
					'img_width' => '150',
					'img_height' => 30
					);

				$data = create_captcha($vals);
				//$this->session->set_userdata(array('captcha_word' => $data['word']));
		                $this->session->set_userdata(array('captcha_word' => "2"));
				$this->load->helper('form');
				$this->db->where("f_id",$f_id);
				$data["forms"]= $this->db->get('forms');
				$this->load->view('header');
				$this->load->view('forms/show',$data);
				$this->load->view('footer');
				
			}	
	}
	
	function management()
    {
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
		
		
		$this->load->library('grocery_CRUD');	
		$crud = new grocery_CRUD();
		$crud->set_table('forms');
		
		$crud->display_as('f_title','عنوان فرم');
		$crud->display_as('f_modify_date','تاریخ آخرین تغییر');
		$crud->display_as('f_manager','مسئول فرم');
		$crud->display_as('f_content','فرم');
		$crud->display_as('f_attachment','ضمايم');
		

		$crud->unset_columns('f_content');
		$crud->change_field_type('f_modify_date','invisible');	
		$crud->callback_before_insert(array($this,'_forms_callback_before_insert'));
		$crud->callback_column('f_modify_date',array($this,'_callback_jalali_date'));
		
		$crud->set_relation('f_manager','users','username');
		
		$crud->set_theme('datatables');
		
		$crud->required_fields('f_title','f_manager','f_content');

		$crud->add_action('نمایش', '', 'forms/show','ui-icon-plus');
		$crud->add_action('اطلاعات ارسالی', '', 'forms/data','ui-icon-plus');


		$crud->order_by('f_id','desc');
		
		if($this->session->userdata('user_group')!="root")
		{
				$this->db->where('f_manager', $this->session->userdata('id'));	
		}		
		
	    $output = $crud->render();
		$this->load->view('admin_them/header');
        $this->_example_output($output);       
        $this->load->view('admin_them/footer'); 		
	}

	function _callback_jalali_date($value, $row)
	{	 
		if(isset($value))
		{
			$this->load->library('JalaliCalendar');   
			$gdate=explode(" ",$value);
			list($gyear,$gmonth,$gday)=preg_split('/-/',$gdate[0]);
			list($jyear,$jmonth,$jday) = $this->jalalicalendar->gregorian_to_jalali($gyear,$gmonth,$gday);
			$jdate=$jyear."-".$jmonth."-".$jday;  
			return $gdate[1]." ".$jdate;
		}
	}

	function _forms_callback_before_insert($post_array)
	{
		$post_array['f_modify_date'] = date("Y-m-d H:i:s");
		return $post_array;
	}

    function _example_output($output = null)
    {
        $this->load->view('our_template.php',$output);    
    }
    
    function register()
    {
		if(strtolower($_POST["captcha_word"])==strtolower($this->session->userdata('captcha_word')))
		{
			if(isset($_POST["f_attachment"]))
			{
				$config['upload_path'] = './assets/uploads/forms';
				$config['allowed_types'] = 'gif|jpg|png|pdf|zip|doc|ZIP|DOC|docx';
				//$config['max_size']	= '100';
				$this->load->library('upload', $config);
				if (!$this->upload->do_upload())
				{
					$data['error']= "هیچ فایلی به پیوست فرم در نیامده است، لطفا به مرحله ی قبل بازگردید.";
					$dont_load=TRUE;
				}else{
					$data = array('upload_data' => $this->upload->data());
					$file_name = $data["upload_data"]["file_name"];
					unset($_POST["f_attachment"]);
				}			
			}
			
				if(!isset($dont_load))
				{
					$f_id = $_POST["f_id"];
					unset($_POST["f_id"]);
					unset($_POST["captcha_word"]);

					$this->db->where("f_id",$f_id);
					$query = $this->db->get('forms');
					$row = $query->row();
					$regex = "#(\[\[)(.*),(.*)(\]\])#e";
					$fd_content = preg_replace($regex,"('[[$2]]')",$row->f_content);

					$counter=0;
					foreach($_POST as $item)
					{
						$counter = $counter + 1 ;
						$fd_content = str_replace("[[$counter]]",$_POST[$counter],$fd_content);
					}
					
					
					$data = array("f_id"=>$f_id,"fd_content"=>$fd_content,"fd_create_date"=>date("Y-m-d H:i:s"));
					if($this->db->insert('forms_data', $data))
					{
						$id = $this->db->insert_id();
						
						if(isset($file_name))
						{
							$data = array("fd_id"=>$id,"fa_address"=>$file_name);
							if(!$this->db->insert('forms_attachment', $data))
								$data['error']="متاسفانه فایل شما پیوست فرم نشد!";
							
						}
						
						
						$data['massege'] = 'کاربر گرامی فرم شما با موفقیت ثبت شد. شماره پیگیری شما: '.$id;
						
					
						$content ="یک فرم جدید در زیر مجموعه ". $_POST["f_title"] ." فرستاده شده است.";	
						$this->db->where('id', $_POST["f_manager"]);
						$query= $this->db->get("users");
						$row = $query->row();
						$to = $row->username;
												
						$this->aylin->send_mail("فرم جدیدی در حوزه مدیریتی شما ارسال شده است",$content,$to);
						
						
					}else{
						$data['error']= 'متاسفانه در روند ذخیره سازی مشکلی پیش آمد، لطفا به مدیر سایت اطلاع دهید';
					}
				}
				
			}else{
				 $data['error']= "حروف وارد شده با حروف موجود در تصویر مطابقت ندارد، لطفا دوباره سعی کنید";
			}
		
		
		$this->load->view('header');
		$this->load->view('forms/register',$data);
		$this->load->view('footer');
		
	}
	
	function data($f_id=null)	
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
		
		
		if(isset($f_id))
		{
			$this->load->library('grocery_CRUD');	
			$crud = new grocery_CRUD();
			$crud->set_table('forms_data');

			$crud->display_as('f_id','فرم');
			$crud->display_as('fd_create_date','تاریخ ارسال');
			$crud->display_as('fd_checked','وضعیت رسیدگی');
			$crud->display_as('fd_checked_date','زمان رسیدگی');

			$crud->unset_columns('fd_content');

			$crud->callback_column('fd_create_date',array($this,'_callback_jalali_date'));
			$crud->callback_column('fd_checked_date',array($this,'_callback_jalali_date'));

			$crud->set_relation('f_id','forms','f_title');
			
			$crud->set_theme('datatables');

			$this->db->where('forms_data.f_id', $f_id);

			$crud->add_action('نمایش', '', 'forms/show_register_data','ui-icon-plus');
			$crud->add_action('رسیدگی شد', '', 'forms/check','ui-icon-plus');

            $crud->unset_add();
            $crud->unset_edit();
            if($this->session->userdata('user_group')!="root")
				$crud->unset_delete();

			$crud->order_by('fd_id','desc');
				
			
			$output = $crud->render();
			$this->load->view('admin_them/header');
			$this->_example_output($output);       
			$this->load->view('admin_them/footer'); 	
		}
	}
	
	function show_register_data($fd_id=NULL)
	{
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
		
		
			if(isset($fd_id))
			{
				$this->db->where("fd_id",$fd_id);
				$data["query"]= $this->db->get('forms_data');
				$this->db->where("fd_id",$fd_id);
				$data["forms_attachment"]= $this->db->get('forms_attachment');
				$this->load->view('admin_them/header');
				$this->load->view('forms/show_register_data',$data);
				$this->load->view('admin_them/footer');
			}			
		
		
	}
	
	
	function check($fd_id=NULL)
	{
		
		$this->aylin->login_check();
		if(!$this->aylin->acl_check($this->uri->segment(1)))
			redirect('/users/login', 'refresh');
							
		if(isset($fd_id))
		{
			$data=array("fd_checked"=>1,"fd_checked_date"=>date("Y-m-d H:i:s"));
			$this->db->where('fd_id', $fd_id);
			if($this->db->update('forms_data', $data))
			{
				$data['massege'] ="وظعیت فرم مورد نظر به رسیدگی شده تغییر کرد.";
			}else{
				$data['error'] ="متاسفانه در روند مورد نظر مشکلی پش آمد";
			}
			
			$this->load->view('admin_them/header');
			$this->load->view('forms/checked',$data);       
			$this->load->view('admin_them/footer'); 
		}		
		
	}
	
	function track()
	{
		if(isset($_POST["fd_id"]))
		{
				$this->db->where("fd_id",$_POST["fd_id"]);
				$data["query"]= $this->db->get('forms_data');
				$this->load->view('header');
				$this->load->view('forms/track',$data);       
				$this->load->view('footer'); 
		}
		
	}
	
	
	function help_user()
	{
				$this->load->view('header');
				$this->load->view('forms/help_user');       
				$this->load->view('footer'); 
	}
	
}
