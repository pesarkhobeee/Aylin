INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES
(0, 'forms', 'manager', 'acl'),
(0, 'forms', 'root', 'acl');

INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_url`, `menu_section`, `parent`) VALUES
(0, 'فرم ها', 'forms/management', 'root', NULL),
(0, 'فرم ها', 'forms', 'public', NULL),
(0, 'فرم ها', 'forms/management', 'manager', NULL);
