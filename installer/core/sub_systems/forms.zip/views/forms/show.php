<?php
			$row=$forms->row();
			
				
				$regex = "#(\[\[)(.*),(.*)(\]\])#e";
				$output = preg_replace($regex,"('<input type=\'text\' name=\'$2\' class=\'span$3\' >')",$row->f_content);

				echo form_open_multipart('forms/register');
				echo "<p style='direction:rtl;text-align:right'>"; 
				echo anchor("forms/show/".$row->f_id,$row->f_title);
				echo "</p>";
				echo "<input type='hidden' name='f_id' value='".$row->f_id."' />";
				echo "<hr>";
				echo $output;
				echo "<br><hr>";
				
				if($row->f_attachment==TRUE)
				{
					echo '<p style="direction:rtl;text-align:right">';
					echo anchor("welcome/index/form_user_help", "برای پیوست مدارک خواسته شده در فرم لطفا این راهنما را مطالعه بفرمایید",array("target"=>"_blank"));
					echo '<br>';
					echo '<input type="hidden" name="f_attachment" value="true" />';
					echo '<input type="file" name="userfile" size="20"  />';
					echo '<hr></p>';
				}
				echo '<input type="hidden" name="f_title" value="'.$row->f_title.'" />';
				echo '<input type="hidden" name="f_manager" value="'.$row->f_manager.'" />';
				echo '<p style="direction:rtl;text-align:right">';
				//echo $image;
				//echo("<br>");
				//echo form_label('کد تصویر بالا را وارید کنید', 'mc_captcha_word');
				//echo form_input(array('id'=>'captcha_word','name'=>'captcha_word'));				
                                echo '<input type="hidden" name="captcha_word"  value="2"/>';
				echo '<br>
				<input class="btn btn-success" type="submit" value="ثبت" onclick="return confirm(\'قبل از ارسال اطلاعات آیا از صحت آنها اطمینان دارید؟\')" />
				</p>';
	
				echo form_close(); 
				
			
?>
