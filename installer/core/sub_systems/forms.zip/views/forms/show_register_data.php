<?php
				$row = $query->row();
				
				echo $row->fd_content;
				echo "<hr>";
				
				$row2 = $forms_attachment->row();
				
				if($forms_attachment->num_rows() > 0)
				{
					echo anchor(base_url("/assets/uploads/forms/".$row2->fa_address),"دریافت فایل پیوست");				
				}

?>
