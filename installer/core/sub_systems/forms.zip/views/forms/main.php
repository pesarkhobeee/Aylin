<div style="direction:rtl;text-align:right">
<h3>فرم ها</h3>
<hr>
	<?php echo $this->aylin->links("forms","red_fonts"); ?>
</div>
<br>

<div style="direction:rtl;text-align:right">
	<h3>فرم های الکترونیکی</h3>
<hr>
<ul style="direction:rtl;text-align:right">
<?php
			foreach ($forms->result() as $row)
			{
				echo "<li>".anchor("forms/show/".$row->f_id,$row->f_title)."</li>";
			}
?>
</ul>
</div>

<div style="direction:rtl;text-align:right">
	<hr>
<h4>پیگیری وضعیت رسیدگی فرم ثبت شده</h4>
<?php
	echo form_open('forms/track');
	echo form_label('کد پیگیری', 'fd_id');
	echo form_input(array('name'=>'fd_id'));				
	echo '<br>
	<input class="btn" type="submit" value="جستجو" onclick="return confirm(\'قبل از ارسال آیا ازصحت کد اطمینان دارید؟\')" />';
	echo form_close(); 
?>
</div>
