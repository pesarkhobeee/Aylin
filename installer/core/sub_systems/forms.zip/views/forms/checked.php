<?php
	if(isset($massege)){echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
      $massege</div>";}
?>


<?php
	if(isset($error)){echo "<div class='fade in alert alert-warning'>
        <a data-dismiss='alert' class='close'>×</a>
      $error</div>";}
?>


<div style="direction:rtl;text-align:right">
<?php

	echo anchor("forms/management","بازگشت به مدیریت فرم ها");


?>
</div>
