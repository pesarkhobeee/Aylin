<?php
	$row = $query->row();
	if($row->fd_checked!=0)
	{
		echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
      ارباب رجوع گرامی، فرم شما مورد رسیدگی قرار گرفته است</div>";
	}else{
		echo "<div class='fade in alert alert-warning'>
        <a data-dismiss='alert' class='close'>×</a>
      ارباب رجوع گرامی، متاسفانه هنوز به فرم شما رسیدگی نشده است</div>";
	}
