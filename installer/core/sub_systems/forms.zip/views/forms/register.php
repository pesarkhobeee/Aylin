<?php
	if(isset($massege)){echo "<div class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
      $massege</div>";}
?>


<?php
	if(isset($error)){echo "<div class='fade in alert alert-warning'>
        <a data-dismiss='alert' class='close'>×</a>
      $error</div>
<input type='button' value='&#1576;&#1575;&#1586;&#1711;&#1588;&#1578; &#1576;&#1607; &#1601;&#1585;&#1605;' onclick='goBack()'>";}
?>
