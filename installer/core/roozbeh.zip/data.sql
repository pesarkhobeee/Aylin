INSERT INTO `meta_data` (`id`, `name`, `value`, `group`) VALUES (NULL, 'roozbeh', 'root', 'acl'); 
