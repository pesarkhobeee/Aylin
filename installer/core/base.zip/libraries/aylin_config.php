<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class aylin_config {

	function config($name,$group){
		$CI =& get_instance();
		$CI->load->database();
		$CI->db->where('group', $group); 
		$CI->db->where('name', $name); 
		$query = $CI->db->get("meta_data");
		return $query->row("value");
	}

}
