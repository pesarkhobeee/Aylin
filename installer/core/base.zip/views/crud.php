<link type="text/css" rel="stylesheet" href="<?php echo base_url("/assets/grocery_crud/themes/flexigrid/css/flexigrid.css"); ?>" />
<script src="<?php echo base_url("/assets/grocery_crud/js/jquery-1.7.1.min.js"); ?>"></script>
<script src="<?php echo base_url("/assets/grocery_crud/js/jquery_plugins/jquery.chosen.min.js"); ?>"></script>
<script src="<?php echo base_url("/assets/grocery_crud/js/jquery_plugins/ajax-chosen.js"); ?>"></script>
<script src="<?php echo base_url("/assets/grocery_crud/js/jquery_plugins/config/jquery.chosen.config.js"); ?>"></script>
<script src="<?php echo base_url("/assets/grocery_crud/js/jquery_plugins/jquery-ui-1.8.10.custom.min.js"); ?>"></script>
<script src="<?php echo base_url("/assets/grocery_crud/js/jquery_plugins/config/jquery.datepicker.config.js"); ?>"></script>
<script src="<?php echo base_url("/assets/grocery_crud/themes/flexigrid/js/jquery.form.js"); ?>"></script>
<script src="<?php echo base_url("/assets/grocery_crud/themes/flexigrid/js/flexigrid-add.js"); ?>"></script>
<?php echo $output; ?>

