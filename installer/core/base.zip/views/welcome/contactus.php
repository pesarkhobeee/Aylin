		<?php 
			if(isset($msg) && $msg!=""){
					echo "<div style='direction:rtl;' class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
         $msg</div>";
				}

		?>