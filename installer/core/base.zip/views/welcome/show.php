<?php
	foreach($contents->result() as $tmp){
		echo $tmp->content_text;
	}

?>