<?php
	if(isset($massege))
	{echo "<div style='direction:rtl;text-align:right;' class='fade in alert alert-success'>
        <a data-dismiss='alert' class='close'>×</a>
         $massege</div>";
  ?> 
